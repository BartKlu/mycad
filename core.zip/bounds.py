# mycad/core/bounds.py

import math


class Bounds:
    """Axis-aligned bounding box."""

    def __init__(self, points):
        if not points:
            raise ValueError("Bounds require at least one point")

        self.min_x = min(p[0] for p in points)
        self.max_x = max(p[0] for p in points)

        self.min_y = min(p[1] for p in points)
        self.max_y = max(p[1] for p in points)

        self.min_z = min(p[2] for p in points)
        self.max_z = max(p[2] for p in points)

    @property
    def size_x(self):
        return self.max_x - self.min_x

    @property
    def size_y(self):
        return self.max_y - self.min_y

    @property
    def size_z(self):
        return self.max_z - self.min_z

    @property
    def centre_x(self):
        return (self.min_x + self.max_x) / 2

    @property
    def centre_y(self):
        return (self.min_y + self.max_y) / 2

    @property
    def centre_z(self):
        return (self.min_z + self.max_z) / 2

    def union(self, other):
        """Return bounds containing both bounding boxes."""

        return Bounds([
            (min(self.min_x, other.min_x),
             min(self.min_y, other.min_y),
             min(self.min_z, other.min_z)),

            (max(self.max_x, other.max_x),
             max(self.max_y, other.max_y),
             max(self.max_z, other.max_z))
        ])

    def corners(self):
        """Return the eight corners of the bounding box."""

        return [
            (x, y, z)
            for x in (self.min_x, self.max_x)
            for y in (self.min_y, self.max_y)
            for z in (self.min_z, self.max_z)
        ]

    def transformed(self, transforms):
        """Return bounds after applying the supplied transformations."""

        points = self.corners()

        for transform in transforms:
            transformed = []

            if transform.kind == "translate":
                dx, dy, dz = transform.values

                transformed = [
                    (x + dx, y + dy, z + dz)
                    for x, y, z in points
                ]

            elif transform.kind == "rotate_z":
                angle, cx, cy, cz = transform.values

                radians = math.radians(-angle)
                cos_a = math.cos(radians)
                sin_a = math.sin(radians)

                for x, y, z in points:
                    rx = x - cx
                    ry = y - cy

                    x_new = rx * cos_a - ry * sin_a
                    y_new = rx * sin_a + ry * cos_a

                    transformed.append((
                        x_new + cx,
                        y_new + cy,
                        z
                    ))

            else:
                raise ValueError(
                    f"Unknown transformation: {transform.kind}"
                )

            points = transformed

        return Bounds(points)

    def __repr__(self):
        return (
            f"Bounds("
            f"x={self.min_x:g}..{self.max_x:g}, "
            f"y={self.min_y:g}..{self.max_y:g}, "
            f"z={self.min_z:g}..{self.max_z:g})"
        )