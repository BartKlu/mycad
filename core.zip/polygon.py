# mycad/core/polygon.py

import math

# mycad/core/polygon.py

class Polygon:
    def __init__(self, points):
        if len(points) < 3:
            raise ValueError("A polygon requires at least 3 points")

        self.points = []

        for point in points:
            if len(point) == 2:
                x, y = point
                z = 0.0
            elif len(point) == 3:
                x, y, z = point
                if z != 0:
                    raise ValueError("Polygon points must have Z = 0")
            else:
                raise ValueError("A point must contain 2 or 3 values")

            self.points.append((float(x), float(y), float(z)))

    @property
    def count(self):
        return len(self.points)

    def translate(self, dx=0, dy=0, dz=0):
        """Translate all polygon points."""

        self.points = [
            (x + dx, y + dy, z + dz)
            for x, y, z in self.points
        ]

        return self

    def copy(self):
        """Return an independent copy of the polygon."""

        return Polygon(self.points)

    def triangulate(self):
        """
        Triangulate the polygon using ear clipping.

        Returns a list of tuples containing point indexes.
        The polygon is assumed to be counter-clockwise.
        """

        if self.count < 3:
            raise ValueError("A polygon requires at least 3 points")

        # Work with indexes so the original polygon is not modified.
        remaining = list(range(self.count))
        triangles = []

        while len(remaining) > 3:
            ear_found = False

            for i in range(len(remaining)):
                prev_index = remaining[i - 1]
                curr_index = remaining[i]
                next_index = remaining[(i + 1) % len(remaining)]

                a = self.points[prev_index]
                b = self.points[curr_index]
                c = self.points[next_index]

                # An ear must be convex.
                if not self._is_convex(a, b, c):
                    continue

                # Nothing else in the polygon may lie inside this triangle.
                is_ear = True

                for point_index in remaining:
                    if point_index in (prev_index, curr_index, next_index):
                        continue

                    if self._point_in_triangle(
                        self.points[point_index], a, b, c
                    ):
                        is_ear = False
                        break

                if not is_ear:
                    continue

                triangles.append(
                    (prev_index, curr_index, next_index)
                )

                del remaining[i]
                ear_found = True
                break

            if not ear_found:
                raise ValueError(
                    "Could not triangulate polygon. "
                    "It may be self-intersecting or invalid."
                )

        triangles.append(
            (remaining[0], remaining[1], remaining[2])
        )

        return triangles

    @staticmethod
    def _is_convex(a, b, c):
        """Return True if A-B-C makes a counter-clockwise turn."""

        cross = (
            (b[0] - a[0]) * (c[1] - b[1])
            - (b[1] - a[1]) * (c[0] - b[0])
        )

        return cross > 0

    @staticmethod
    def _point_in_triangle(p, a, b, c):
        """Return True if point P lies inside triangle ABC."""

        def cross(p1, p2, p3):
            return (
                (p2[0] - p1[0]) * (p3[1] - p1[1])
                - (p2[1] - p1[1]) * (p3[0] - p1[0])
            )

        c1 = cross(a, b, p)
        c2 = cross(b, c, p)
        c3 = cross(c, a, p)

        # For a CCW triangle, an interior point is on the
        # left side of all three edges.
        return c1 >= 0 and c2 >= 0 and c3 >= 0
        
    def edges(self):
        """Return the polygon boundary as pairs of point indexes."""

        return [
            (i, (i + 1) % self.count)
            for i in range(self.count)
        ]   

    def offset(self, distance):
        """Return a polygon offset outward by distance.

        The polygon must be counter-clockwise.

        Positive distance expands the polygon.
        Negative distance contracts it.
        """

        if self.count < 3:
            raise ValueError("A polygon requires at least 3 points")

        if distance == 0:
            return self.copy()

        # Create the offset line for each polygon edge.
        lines = []

        for i in range(self.count):
            p1 = self.points[i]
            p2 = self.points[(i + 1) % self.count]

            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]

            length = math.hypot(dx, dy)

            if length == 0:
                raise ValueError(
                    "Polygon contains a zero-length edge"
                )

            # Outward normal for a CCW polygon.
            nx = dy / length
            ny = -dx / length

            # Shift the complete edge outward.
            ox = nx * distance
            oy = ny * distance

            lines.append((
                (p1[0] + ox, p1[1] + oy),
                (p2[0] + ox, p2[1] + oy)
            ))

        # Find intersections of adjacent offset edges.
        new_points = []

        for i in range(self.count):
            previous_line = lines[i - 1]
            current_line = lines[i]

            point = self._line_intersection(
                previous_line[0],
                previous_line[1],
                current_line[0],
                current_line[1]
            )

            new_points.append(point)

        return Polygon(new_points)   

    @staticmethod
    def _line_intersection(p1, p2, p3, p4):
        """Return the intersection of two infinite 2D lines."""

        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = p3
        x4, y4 = p4

        dx1 = x2 - x1
        dy1 = y2 - y1
        dx2 = x4 - x3
        dy2 = y4 - y3

        denominator = (
            dx1 * dy2
            - dy1 * dx2
        )

        if abs(denominator) < 1e-12:
            raise ValueError(
                "Cannot offset polygon: "
                "adjacent edges are parallel"
            )

        t = (
            (x3 - x1) * dy2
            - (y3 - y1) * dx2
        ) / denominator

        return (
            x1 + t * dx1,
            y1 + t * dy1
        )    
