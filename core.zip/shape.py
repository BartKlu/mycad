# mycad/core/shape.py
#

import math
from .hole import Hole
from .boolean import BooleanShape
from .transform import Transform
from .bounds import Bounds
from .pocket import Pocket
from .polygon import Polygon
from .boss import Boss
from .profile import Profile
from .face import FACE

def polygon_area_2d(pts):
    """Return signed area of a 2D polygon. Positive = CCW, Negative = CW."""
    area = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return area / 2.0

class Shape:
    def __init__(self, polygon):
        self.metadata = {}
        
        # Make our own copy of the polygon
        self.polygon = polygon.copy()

        # Bottom points are the polygon points
        self.bottom_points = self.polygon.points.copy()

        # Initially the top is identical to the bottom
        self.top_points = self.bottom_points.copy()
        
        self.features = []
        
        # Rigid transformations, in the order requested.
        self.transforms = []
        
        self.top_z_value = None

        self._is_loft = False
        self.loft_bottom = None
        self.loft_top = None
        self.bottom_z = 0
        
    @property
    def count(self):
        return len(self.bottom_points)
       
    @property
    def holes(self):
        """Return the holes currently attached to the shape."""

        return [
            feature
            for feature in self.features
            if isinstance(feature, Hole)
        ]

    def top_z(self, z):
        """
        Set the Z value of all top points, or set individual Z values
        from a list or tuple.
        """

        if isinstance(z, (int, float)):
            self.top_points = [
                (x, y, float(z))
                for x, y, _ in self.top_points
            ]
            self.top_z_value = float(z)  # <-- store single Z
        else:
            if len(z) != self.count:
                raise ValueError(
                    "Number of top Z values must match polygon point count"
                )

            self.top_points = [
                (x, y, float(zi))
                for (x, y, _), zi in zip(self.top_points, z)
            ]
            # For multi-Z walls, store the average or first value
            self.top_z_value = float(z[0])
        return self
        
    def slant(self, dx=0, dy=0):
        """Move all top points by dx and dy."""

        self.top_points = [
            (x + dx, y + dy, z)
            for x, y, z in self.top_points
        ]

        return self
        
    def build(self):
        """Build the Shape using the CAD backend."""

        from ..freecad.builder import make_solid

        return make_solid(self)

    def hole(self, diameter, name = None, pos=(0, 0, None), depth=None, direction=(0, 0, -1)):
        """Add a cylindrical hole to the shape."""
        # Accept pos=(x, y) or pos=(x, y, z)
        if len(pos) == 2:
            px, py = pos
            pz = None
        else:
            px, py, pz = pos

        self.features.append(
            Hole(
                px,
                py,
                diameter,
                depth,
                direction,
                z=pz,
                name=name
            )
        )

        return self   

    def hole_on_face(self, profile, face, u=0.5, v=0.5, depth=1.0, inset=0.0):
        """
        Place a 2D profile on the requested face and create a hole
        (cut inward along the face normal).

        face: FACE enum (TOP, BOTTOM, FRONT, BACK, LEFT, RIGHT)
        u, v: parametric coordinates on the face
        depth: hole depth (positive number)
        inset: move slightly inward along face normal before cutting
        """

        # 1. Dispatch to the correct face-placement function
        if face == FACE.FRONT:
            placed = self.place_profile_on_front_face(profile, u=u, v=v, inset=inset)
            normal = (0, -1, 0)

        elif face == FACE.BACK:
            placed = self.place_profile_on_back_face(profile, u=u, v=v, inset=inset)
            normal = (0, 1, 0)

        elif face == FACE.LEFT:
            placed = self.place_profile_on_left_face(profile, u=u, v=v, inset=inset)
            normal = (-1, 0, 0)

        elif face == FACE.RIGHT:
            placed = self.place_profile_on_right_face(profile, u=u, v=v, inset=inset)
            normal = (1, 0, 0)

        elif face == FACE.TOP:
            placed = self.place_profile_on_top_surface(profile, u=u, v=v, inset=inset)
            normal = (0, 0, 1)

        elif face == FACE.BOTTOM:
            placed = self.place_profile_on_bottom_surface(profile, u=u, v=v, inset=inset)
            normal = (0, 0, -1)

        else:
            raise ValueError(f"Unsupported face: {face}")

        # 2. Cut inward along the face normal
        self.hole(placed, depth=depth, direction=normal)

        return placed

    def top_z_at(self, x, y):
        """Return the Z value of the top surface at XY."""

        for indexes in self.polygon.triangulate():
            a = self.top_points[indexes[0]]
            b = self.top_points[indexes[1]]
            c = self.top_points[indexes[2]]

            if self._point_in_triangle_xy(x, y, a, b, c):
                return self._interpolate_z(x, y, a, b, c)

        raise ValueError(
            f"Point ({x}, {y}) is outside the top surface"
        )

    def top_surface_at(self, x, y):
        """Return the top-surface point and unit normal at XY."""

        for indexes in self.polygon.triangulate():

            a = self.top_points[indexes[0]]
            b = self.top_points[indexes[1]]
            c = self.top_points[indexes[2]]

            if self._point_in_triangle_xy(x, y, a, b, c):

                z = self._interpolate_z(x, y, a, b, c)

                # Triangle vectors
                ab = (
                    b[0] - a[0],
                    b[1] - a[1],
                    b[2] - a[2]
                )

                ac = (
                    c[0] - a[0],
                    c[1] - a[1],
                    c[2] - a[2]
                )

                # Cross product AB × AC
                normal = self._cross(ab, ac)

                normal = self._normalise(normal)

                # We want the normal pointing upwards.
                if normal[2] < 0:
                    normal = (
                        -normal[0],
                        -normal[1],
                        -normal[2]
                    )

                return (
                    (x, y, z),
                    normal
                )

        raise ValueError(
            f"Point ({x}, {y}) is outside the top surface"
        )

    @staticmethod
    def _point_in_triangle_xy(x, y, a, b, c):
        """Return True if XY lies inside triangle ABC."""

        def cross(p1, p2, px, py):
            return (
                (p2[0] - p1[0]) * (py - p1[1])
                - (p2[1] - p1[1]) * (px - p1[0])
            )

        c1 = cross(a, b, x, y)
        c2 = cross(b, c, x, y)
        c3 = cross(c, a, x, y)

        return c1 >= 0 and c2 >= 0 and c3 >= 0

    @staticmethod
    def _interpolate_z(x, y, a, b, c):
        """Interpolate Z on triangle ABC."""

        denominator = (
            (b[1] - c[1]) * (a[0] - c[0])
            + (c[0] - b[0]) * (a[1] - c[1])
        )

        if abs(denominator) < 1e-12:
            raise ValueError("Degenerate triangle")

        wa = (
            (b[1] - c[1]) * (x - c[0])
            + (c[0] - b[0]) * (y - c[1])
        ) / denominator

        wb = (
            (c[1] - a[1]) * (x - c[0])
            + (a[0] - c[0]) * (y - c[1])
        ) / denominator

        wc = 1 - wa - wb

        return (
            wa * a[2]
            + wb * b[2]
            + wc * c[2]
        )
        
    def max_top_z_in_circle(self, x, y, radius):
        """Return the highest top-surface Z inside an XY circle."""

        if radius <= 0:
            raise ValueError("Radius must be positive")

        maximum_z = None

        for indexes in self.polygon.triangulate():
            a = self.top_points[indexes[0]]
            b = self.top_points[indexes[1]]
            c = self.top_points[indexes[2]]

            candidates = []

            # Triangle vertices inside the circle.
            for p in (a, b, c):
                if self._point_in_circle(x, y, radius, p):
                    candidates.append(p)

            # Circle centre if it lies inside the triangle.
            if self._point_in_triangle_xy(x, y, a, b, c):
                candidates.append((x, y, self._interpolate_z(x, y, a, b, c)))

            # Intersections between each triangle edge and the circle.
            for p1, p2 in ((a, b), (b, c), (c, a)):
                for px, py in self._line_circle_intersections(
                    p1, p2, x, y, radius
                ):
                    z = self._interpolate_z(px, py, a, b, c)
                    candidates.append((px, py, z))

            for p in candidates:
                if maximum_z is None or p[2] > maximum_z:
                    maximum_z = p[2]

        if maximum_z is None:
            raise ValueError(
                "Circle does not intersect the top surface"
            )

        return maximum_z

    @staticmethod
    def _point_in_circle(cx, cy, radius, p):
        dx = p[0] - cx
        dy = p[1] - cy
        return dx * dx + dy * dy <= radius * radius

    @staticmethod
    def _line_circle_intersections(p1, p2, cx, cy, radius):
        """Return intersections between a line segment and a circle."""

        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]

        fx = p1[0] - cx
        fy = p1[1] - cy

        a = dx * dx + dy * dy

        if a == 0:
            return []

        b = 2 * (fx * dx + fy * dy)
        c = fx * fx + fy * fy - radius * radius

        discriminant = b * b - 4 * a * c

        if discriminant < 0:
            return []

        discriminant = max(0, discriminant)

        sqrt_d = discriminant ** 0.5

        results = []

        for t in (
            (-b - sqrt_d) / (2 * a),
            (-b + sqrt_d) / (2 * a)
        ):
            if 0 <= t <= 1:
                results.append((
                    p1[0] + t * dx,
                    p1[1] + t * dy
                ))

        return results    
        
    def hole_entry_point(self, hole):
        """
        Find the first point where the hole cylinder meets the
        top surface.

        The hole direction points into the object. The returned
        point is the point on the top surface furthest outward
        along that direction.
        """
        
        radius = hole.diameter / 2

        # The hole axis passes through the top surface at (x, y), or if hole.z is provided, use it
        if hole.z is not None:
            origin = (hole.x, hole.y, hole.z)
        else:
            origin = (hole.x, hole.y, self.top_z_at(hole.x, hole.y))

        dx, dy, dz = hole.direction

        # Side-entry: axis parallel to top surface → no top intersection
        if abs(dz) < 1e-6:
            # Optional: normalize direction for later use
            length = math.sqrt(dx*dx + dy*dy + dz*dz)
            if length > 0:
                dx, dy, dz = dx/length, dy/length, dz/length
            # For side holes, just use the given origin as entry point
            return origin

        direction = (dx, dy, dz)

        # Construct two unit vectors perpendicular to the hole axis.
        if abs(dz) < 0.9:
            reference = (0.0, 0.0, 1.0)
        else:
            reference = (1.0, 0.0, 0.0)

        u = self._cross(direction, reference)
        u = self._normalise(u)

        v = self._cross(direction, u)
        v = self._normalise(v)

        best_point = None
        best_t = None

        # --- promote bottom polygon to 3D and triangulate ---
        poly = self.polygon.points
        if len(poly[0]) == 2:
            # lofted wall: add bottom_z
            poly = [(x, y, self.bottom_z) for (x, y) in poly]

        triangles = Polygon(poly).triangulate()

        for indexes in triangles:
            # top_points may be 2D (loft) or 3D (extrusion)
            a = self.top_points[indexes[0]]
            b = self.top_points[indexes[1]]
            c = self.top_points[indexes[2]]

            # Promote 2D top_points to 3D using top_z
            if len(a) == 2:
                a = (a[0], a[1], self.top_z)
                b = (b[0], b[1], self.top_z)
                c = (c[0], c[1], self.top_z)

            # Transform triangle into coordinates relative to
            # the hole axis:
            #
            # u, v = coordinates perpendicular to the axis
            # t    = distance along the axis

            ta = self._axis_coordinates(a, origin, u, v, direction)
            tb = self._axis_coordinates(b, origin, u, v, direction)
            tc = self._axis_coordinates(c, origin, u, v, direction)

            candidates = []

            # The hole axis starts at this point on the top surface.
            # If that point lies inside this triangle, it is a valid
            # candidate for the entry position.
            if self._point_in_triangle_xy(
                origin[0],
                origin[1],
                a,
                b,
                c
            ):
                candidates.append(origin)

            # Triangle vertices inside the cylinder.
            for point, q in (
                (a, ta),
                (b, tb),
                (c, tc)
            ):
                if q[0] * q[0] + q[1] * q[1] <= radius * radius:
                    candidates.append(point)

            # Intersections between triangle edges and the
            # circular boundary of the cylinder.
            for p1, q1, p2, q2 in (
                (a, ta, b, tb),
                (b, tb, c, tc),
                (c, tc, a, ta)
            ):
                for t in self._segment_circle_intersections(
                    q1[0], q1[1],
                    q2[0], q2[1],
                    radius
                ):
                    point = (
                        p1[0] + t * (p2[0] - p1[0]),
                        p1[1] + t * (p2[1] - p1[1]),
                        p1[2] + t * (p2[2] - p1[2])
                    )

                    candidates.append(point)

            # The minimum of t over the circular portion of the
            # triangle can occur at the support point of the
            # triangle plane on the cylinder.
            support = self._cylinder_support_point(
                ta, tb, tc, radius
            )

            if support is not None:
                su, sv = support

                bary = self._barycentric_2d(
                    su, sv,
                    ta[0], ta[1],
                    tb[0], tb[1],
                    tc[0], tc[1]
                )

                if bary is not None and min(bary) >= -1e-10:
                    wa, wb, wc = bary

                    candidates.append((
                        wa * a[0] + wb * b[0] + wc * c[0],
                        wa * a[1] + wb * b[1] + wc * c[1],
                        wa * a[2] + wb * b[2] + wc * c[2]
                    ))

            for point in candidates:
                t = (
                    (point[0] - origin[0]) * direction[0]
                    + (point[1] - origin[1]) * direction[1]
                    + (point[2] - origin[2]) * direction[2]
                )

                # Direction points INTO the object, so the first
                # point encountered is the smallest t.
                if best_t is None or t < best_t:
                    best_t = t
                    best_point = point

        if best_point is None:
            print("shape.hole_entry_point: ", hole.x, hole.y, hole.z)
            err = (
                f"Hole {hole.name} does not intersect the desired surface "
                f"({hole.x}, {hole.y}, {hole.z})"
            )
            raise ValueError(err)

        # Convert the extreme surface point into the corresponding
        # centre of the entry circle, which lies on the hole axis.

        t = (
            (best_point[0] - origin[0]) * direction[0]
            + (best_point[1] - origin[1]) * direction[1]
            + (best_point[2] - origin[2]) * direction[2]
        )

        return (
            origin[0] + t * direction[0],
            origin[1] + t * direction[1],
            origin[2] + t * direction[2]
        )
        
    @staticmethod
    def _cross(a, b):
        return (
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]
        )

    @staticmethod
    def _normalise(v):
        import math

        length = math.sqrt(
            v[0] * v[0] +
            v[1] * v[1] +
            v[2] * v[2]
        )

        if length == 0:
            raise ValueError("Cannot normalise zero vector")

        return (
            v[0] / length,
            v[1] / length,
            v[2] / length
        )

    @staticmethod
    def _axis_coordinates(point, origin, u, v, direction):
        dx = point[0] - origin[0]
        dy = point[1] - origin[1]
        dz = point[2] - origin[2]

        return (
            dx * u[0] + dy * u[1] + dz * u[2],
            dx * v[0] + dy * v[1] + dz * v[2],
            dx * direction[0] + dy * direction[1] + dz * direction[2]
        )

    @staticmethod
    def _segment_circle_intersections(x1, y1, x2, y2, radius):

        dx = x2 - x1
        dy = y2 - y1

        a = dx * dx + dy * dy

        if a == 0:
            return []

        b = 2 * (x1 * dx + y1 * dy)
        c = x1 * x1 + y1 * y1 - radius * radius

        discriminant = b * b - 4 * a * c

        if discriminant < 0:
            return []

        discriminant = max(0.0, discriminant)

        root = math.sqrt(discriminant)

        results = []

        for t in (
            (-b - root) / (2 * a),
            (-b + root) / (2 * a)
        ):
            if 0 <= t <= 1:
                results.append(t)

        return results

    @staticmethod
    def _barycentric_2d(px, py, ax, ay, bx, by, cx, cy):
        denominator = (
            (by - cy) * (ax - cx)
            + (cx - bx) * (ay - cy)
        )

        if abs(denominator) < 1e-12:
            return None

        wa = (
            (by - cy) * (px - cx)
            + (cx - bx) * (py - cy)
        ) / denominator

        wb = (
            (cy - ay) * (px - cx)
            + (ax - cx) * (py - cy)
        ) / denominator

        wc = 1 - wa - wb

        return wa, wb, wc

    @staticmethod
    def _cylinder_support_point(a, b, c, radius):
        """
        Return the point (u,v) on the cylinder boundary where
        the triangle plane has minimum t, if that point lies
        within the projected triangle.
        """

        import math

        ax, ay, at = a
        bx, by, bt = b
        cx, cy, ct = c

        denominator = (
            (by - cy) * (ax - cx)
            + (cx - bx) * (ay - cy)
        )

        if abs(denominator) < 1e-12:
            return None

        # t = A*u + B*v + C over the triangle plane.
        A = (
            (by - cy) * (at - ct)
            + (cy - ay) * (bt - ct)
        ) / denominator

        B = (
            (cx - bx) * (at - ct)
            + (ax - cx) * (bt - ct)
        ) / denominator

        length = math.sqrt(A * A + B * B)

        if length < 1e-12:
            return None

        # Minimum t on a circle of radius r.
        return (
            -radius * A / length,
            -radius * B / length
        )   

    def translate(self, dx=0, dy=0, dz=0):
        """Record a translation to be applied at build time."""

        self.transforms.append(
            Transform.translate(dx, dy, dz)
        )

        return self        

    def rotate(self, angle, x=0, y=0, z=0):
        """Record a clockwise rotation around a point on the Z axis."""

        self.transforms.append(
            Transform.rotate_z(angle, x, y, z)
        )

        return self

    def rotate_about_custom_point(self, angle_deg, px, py, pz):
        angle = math.radians(angle_deg)
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        def rot_point(p):
            # 2D or 3D point, rotated around pivot (px, py, pz)
            if len(p) == 2:
                x, y = p
                z = 0
            else:
                x, y, z = p

            x -= px
            y -= py
            z -= pz

            xr = x * cos_a - y * sin_a
            yr = x * sin_a + y * cos_a
            zr = z

            return (xr + px, yr + py, zr + pz)

        def rot_dir(v):
            # 3D direction vector: rotate around Z, NO pivot translation
            x, y, z = v
            xr = x * cos_a - y * sin_a
            yr = x * sin_a + y * cos_a
            zr = z
            return (xr, yr, zr)

        # --- polygon footprint (2D) ---
        self.polygon.points = [rot_point(p)[:2] for p in self.polygon.points]

        # --- bottom/top points (3D) ---
        self.bottom_points = [rot_point(p) for p in self.bottom_points]
        self.top_points    = [rot_point(p) for p in self.top_points]

        # --- loft points ---
        if self.loft_bottom is not None:
            self.loft_bottom = [rot_point(p) for p in self.loft_bottom]
        if self.loft_top is not None:
            self.loft_top = [rot_point(p) for p in self.loft_top]

        # --- holes ---
        for f in self.features:
            if isinstance(f, Hole):
                # position rotates around pivot
                f.x, f.y, f.z = rot_point((f.x, f.y, f.z))
                # direction rotates as a pure vector
                f.direction = rot_dir(f.direction)

    def rotate_on_face(self, profile, face, angle):
        """
        Rotate a profile within the local coordinate frame of a face.
        angle: degrees, positive = counterclockwise when looking at the face.
        """

        # FRONT and BACK faces lie in XZ plane → rotate around Y axis
        if face in (FACE.FRONT, FACE.BACK):
            # Local rotation around Y
            profile.rotate3d(angle=angle, ax=0, ay=1, az=0)
            return profile

        # LEFT and RIGHT faces lie in YZ plane → rotate around X axis
        if face in (FACE.LEFT, FACE.RIGHT):
            # Local rotation around X
            profile.rotate3d(angle=angle, ax=1, ay=0, az=0)
            return profile

        # TOP and BOTTOM faces lie in XY plane → rotate around Z axis
        if face in (FACE.TOP, FACE.BOTTOM):
            # Local rotation around Z
            profile.rotate3d(angle=angle, ax=0, ay=0, az=1)
            return profile

        raise ValueError(f"Unsupported face: {face}")

    def rotate_on_face_axis(self, profile, face, angle_u=0.0, angle_v=0.0):
        """
        Rotate a profile around the local axes of a face.

        angle_u: rotation around the face's horizontal axis (u direction)
        angle_v: rotation around the face's vertical axis (v direction)

        This is different from rotate_on_face(), which rotates around the face normal.
        Here we rotate around axes *lying in the face plane*.
        """

        # FRONT/BACK faces lie in XZ plane
        if face in (FACE.FRONT, FACE.BACK):
            # u-axis = X direction
            # v-axis = Z direction

            # Rotate around u-axis (X)
            if angle_u != 0:
                profile.rotate3d(angle=angle_u, ax=1, ay=0, az=0)

            # Rotate around v-axis (Z)
            if angle_v != 0:
                profile.rotate3d(angle=angle_v, ax=0, ay=0, az=1)

            return profile

        # LEFT/RIGHT faces lie in YZ plane
        if face in (FACE.LEFT, FACE.RIGHT):
            # u-axis = Y direction
            # v-axis = Z direction

            # Rotate around u-axis (Y)
            if angle_u != 0:
                profile.rotate3d(angle=angle_u, ax=0, ay=1, az=0)

            # Rotate around v-axis (Z)
            if angle_v != 0:
                profile.rotate3d(angle=angle_v, ax=0, ay=0, az=1)
    
            return profile

        # TOP/BOTTOM faces lie in XY plane
        if face in (FACE.TOP, FACE.BOTTOM):
            # u-axis = X direction
            # v-axis = Y direction

            # Rotate around u-axis (X)
            if angle_u != 0:
                profile.rotate3d(angle=angle_u, ax=1, ay=0, az=0)

            # Rotate around v-axis (Y)
            if angle_v != 0:
                profile.rotate3d(angle=angle_v, ax=0, ay=1, az=0)

            return profile

        raise ValueError(f"Unsupported face: {face}")

    def rotate3d(self, angle_deg, ax, ay, az, px=0, py=0, pz=0):
        """
        Rotate the entire shape around an arbitrary axis (ax, ay, az)
        passing through point (px, py, pz).
        """

        angle = math.radians(angle_deg)
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        # Normalize axis
        length = math.sqrt(ax*ax + ay*ay + az*az)
        ux, uy, uz = ax/length, ay/length, az/length

        def rot_point(p):
            x, y, z = p

            # Translate to pivot
            x -= px
            y -= py
            z -= pz

            # Rodrigues' rotation formula
            xr = (cos_a + ux*ux*(1-cos_a))*x + (ux*uy*(1-cos_a) - uz*sin_a)*y + (ux*uz*(1-cos_a) + uy*sin_a)*z
            yr = (uy*ux*(1-cos_a) + uz*sin_a)*x + (cos_a + uy*uy*(1-cos_a))*y + (uy*uz*(1-cos_a) - ux*sin_a)*z
            zr = (uz*ux*(1-cos_a) - uy*sin_a)*x + (uz*uy*(1-cos_a) + ux*sin_a)*y + (cos_a + uz*uz*(1-cos_a))*z

            return (xr + px, yr + py, zr + pz)

        # def rot_dir(v):
            # x, y, z = v

            # # Rodrigues' rotation formula (no pivot translation)
            # xr = (cos_a + ux*ux*(1-cos_a))*x + (ux*uy*(1-cos_a) - uz*sin_a)*y + (ux*uz*(1-cos_a) + uy*sin_a)*z
            # yr = (uy*ux*(1-cos_a) + uz*sin_a)*x + (cos_a + uy*uy*(1-cos_a))*y + (uy*uz*(1-cos_a) - ux*sin_a)*z
            # zr = (uz*ux*(1-cos_a) - uy*sin_a)*x + (uz*uy*(1-cos_a) + ux*sin_a)*y + (cos_a + uz*uz*(1-cos_a))*z

            # return (xr, yr, zr)

        # def transform_feature(f, rot_point, rot_dir):
            # """
            # Apply rotation to any feature: Hole, Boss, Pocket, Loft, etc.
            # """

            # # --- HOLE ---------------------------------------------------------
            # if f.__class__.__name__ == "Hole":
                # # Rotate hole position
                # f.x, f.y, f.z = rot_point((f.x, f.y, f.z))

                # # Rotate hole direction vector
                # dx, dy, dz = f.direction
                # f.direction = rot_dir((dx, dy, dz))
                # return

                # # --- BOSS ---------------------------------------------------------
                # if f.__class__.__name__ == "Boss":

                    # # Rotate boss position (first two coords only)
                    # vals = list(f.pos)
                    # x, y = vals[0], vals[1]
                    # xr, yr, zr = rot_point((x, y, 0))
                    # vals[0], vals[1] = xr, yr
                    # f.pos = tuple(vals)

                    # # Rotate boss direction
                    # dx, dy, dz = f.direction
                    # f.direction = rot_dir((dx, dy, dz))

                    # # Rotate boss profile outer polygon
                    # poly = f.profile.outer
                    # new_points = []
                    # for p in poly.points:
                        # x, y = p[0], p[1]
                        # xr, yr, zr = rot_point((x, y, 0))
                        # new_points.append((xr, yr))
                    # poly.points = new_points

                    # # Rotate boss profile hole polygons
                    # for hole in f.profile.holes:
                        # new_hole_points = []
                        # for p in hole.points:
                            # x, y = p[0], p[1]
                            # xr, yr, zr = rot_point((x, y, 0))
                            # new_hole_points.append((xr, yr))
                        # hole.points = new_hole_points

                    # return

                # # --- POCKET -------------------------------------------------------
                # if f.__class__.__name__ == "Pocket":
                    # # Rotate pocket position (first two coords only)
                    # vals = list(f.pos)
                    # xr, yr, zr = rot_point((vals[0], vals[1], 0))
                    # vals[0], vals[1] = xr, yr
                    # f.pos = tuple(vals)

                    # # Rotate pocket profile outer polygon
                    # poly = f.profile.outer
                    # new_points = []
                    # for p in poly.points:
                        # x, y = p[0], p[1]
                        # xr, yr, zr = rot_point((x, y, 0))
                        # new_points.append((xr, yr))
                    # poly.points = new_points

                    # # Rotate pocket profile hole polygons
                    # for hole in f.profile.holes:
                        # new_hole_points = []
                        # for p in hole.points:
                            # x, y = p[0], p[1]
                            # xr, yr, zr = rot_point((x, y, 0))
                            # new_hole_points.append((xr, yr))
                        # hole.points = new_hole_points

                    # # Rotate pocket direction (tilt)
                    # dx, dy = f.tilt_x, f.tilt_y
                    # dz = 0  # pockets are 2D cuts, direction is in-plane
                    # dxr, dyr, dzr = rot_dir((dx, dy, dz))
                    # f.tilt_x, f.tilt_y = dxr, dyr

                    # # Keep rotation angle
                    # f.rotation = (f.rotation or 0)
                    # return
                # return

            # # --- LOFT ---------------------------------------------------------
            # if f.__class__.__name__ == "Loft":
                # f.bottom = [rot_point(p) for p in f.bottom]
                # f.top    = [rot_point(p) for p in f.top]
                # return

            # # --- FALLBACK: rotate any feature with .pos or .points ------------
            # if hasattr(f, "pos"):
                # vals = list(f.pos)
                # xr, yr, zr = rot_point((vals[0], vals[1], 0))
                # vals[0], vals[1] = xr, yr
                # f.pos = tuple(vals)

            # if hasattr(f, "points"):
                # f.points = [rot_point(p) for p in f.points]

        # Apply to all geometry
        self.bottom_points = [rot_point(p) for p in self.bottom_points]
        self.top_points    = [rot_point(p) for p in self.top_points]

        if self.loft_bottom is not None:
            self.loft_bottom = [rot_point(p) for p in self.loft_bottom]
        if self.loft_top is not None:
            self.loft_top = [rot_point(p) for p in self.loft_top]



    def cut(self, other):
        """Return a Boolean cut without building it yet."""

        return BooleanShape("cut", self, other)

    def fuse(self, other):
        """Return a Boolean fuse without building it yet."""

        return BooleanShape("fuse", self, other) 

    def bounds(self):
        """Return the axis-aligned bounding box after transforms."""

        points = self.bottom_points + self.top_points

        transformed = []

        for point in points:
            transformed.append(
                self._transform_point(point)
            )

        return Bounds(transformed)

    def _transform_point(self, point):
        """Apply this Shape's recorded transforms to one point."""

        x, y, z = point

        for transform in self.transforms:

            if transform.kind == "translate":
                dx, dy, dz = transform.values

                x += dx
                y += dy
                z += dz

            elif transform.kind == "rotate_z":
                angle, cx, cy, cz = transform.values

                # Our API uses clockwise-positive angles.
                # Convert to mathematical CCW angle.
                radians = math.radians(-angle)

                # Move to rotation centre.
                rx = x - cx
                ry = y - cy

                cos_a = math.cos(radians)
                sin_a = math.sin(radians)

                x_new = rx * cos_a - ry * sin_a
                y_new = rx * sin_a + ry * cos_a

                x = x_new + cx
                y = y_new + cy

                # Rotation is around the Z axis through (cx, cy, cz).
                z = z

            else:
                raise ValueError(
                    f"Unknown transformation: {transform.kind}"
                )

        return x, y, z  

    def mirror_on_face(self, profile, face, axis='u'):
        """
        Mirror a profile within the local coordinate frame of a face.

        axis:
            'u' = horizontal axis on the face
            'v' = vertical axis on the face

        Mirroring is done in the face's own coordinate system:
            FRONT/BACK → XZ plane
            LEFT/RIGHT → YZ plane
            TOP/BOTTOM → XY plane
        """

        # FRONT/BACK faces lie in XZ → mirror in X or Z
        if face in (FACE.FRONT, FACE.BACK):
            if axis == 'u':
                # mirror horizontally → flip X
                profile.scale3d(sx=-1, sy=1, sz=1)
            elif axis == 'v':
                # mirror vertically → flip Z
                profile.scale3d(sx=1, sy=1, sz=-1)
            else:
                raise ValueError("axis must be 'u' or 'v'")
            return profile

        # LEFT/RIGHT faces lie in YZ → mirror in Y or Z
        if face in (FACE.LEFT, FACE.RIGHT):
            if axis == 'u':
                # mirror horizontally → flip Y
                profile.scale3d(sx=1, sy=-1, sz=1)
            elif axis == 'v':
                # mirror vertically → flip Z
                profile.scale3d(sx=1, sy=1, sz=-1)
            else:
                raise ValueError("axis must be 'u' or 'v'")
            return profile

        # TOP/BOTTOM faces lie in XY → mirror in X or Y
        if face in (FACE.TOP, FACE.BOTTOM):
            if axis == 'u':
                # mirror horizontally → flip X
                profile.scale3d(sx=-1, sy=1, sz=1)
            elif axis == 'v':
                # mirror vertically → flip Y
                profile.scale3d(sx=1, sy=-1, sz=1)
            else:
                raise ValueError("axis must be 'u' or 'v'")
            return profile

        raise ValueError(f"Unsupported face: {face}")

    def center_on_face(self, profile, face, inset=0.0):
        """
        Center a profile on the requested face.

        This computes the midpoint of the face bounds and moves the profile
        so that its own center aligns with the face center.

        inset: optional offset inward along the face normal.
        """

        # 1. Get face bounds
        if face == FACE.FRONT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.front_face_bounds()
            face_center = ((xmin + xmax) / 2, ymin, (zmin + zmax) / 2)
            normal = (0, -1, 0)

        elif face == FACE.BACK:
            xmin, xmax, ymin, ymax, zmin, zmax = self.back_face_bounds()
            face_center = ((xmin + xmax) / 2, ymax, (zmin + zmax) / 2)
            normal = (0, 1, 0)

        elif face == FACE.LEFT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.left_face_bounds()
            face_center = (xmin, (ymin + ymax) / 2, (zmin + zmax) / 2)
            normal = (-1, 0, 0)

        elif face == FACE.RIGHT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.right_face_bounds()
            face_center = (xmax, (ymin + ymax) / 2, (zmin + zmax) / 2)
            normal = (1, 0, 0)

        elif face == FACE.TOP:
            xmin, xmax, ymin, ymax, zmin, zmax = self.top_surface_bounds()
            face_center = ((xmin + xmax) / 2, (ymin + ymax) / 2, zmax)
            normal = (0, 0, 1)

        elif face == FACE.BOTTOM:
            xmin, xmax, ymin, ymax, zmin, zmax = self.bottom_surface_bounds()
            face_center = ((xmin + xmax) / 2, (ymin + ymax) / 2, zmin)
            normal = (0, 0, -1)

        else:
            raise ValueError(f"Unsupported face: {face}")

        # 2. Compute profile center
        xs = []
        ys = []
        zs = []
        for region in profile.regions:
            for poly in region:
                for (x, y, z) in poly.points:
                    xs.append(x)
                    ys.append(y)
                    zs.append(z)

        cx = (min(xs) + max(xs)) / 2
        cy = (min(ys) + max(ys)) / 2
        cz = (min(zs) + max(zs)) / 2

        # 3. Move profile center to face center
        dx = face_center[0] - cx - inset * normal[0]
        dy = face_center[1] - cy - inset * normal[1]
        dz = face_center[2] - cz - inset * normal[2]
    
        profile.translate(dx=dx, dy=dy, dz=dz)

        return profile

    def array_on_face(self, profile, face, count_u=1, count_v=1,
                    spacing_u=5.0, spacing_v=5.0, inset=0.0):
        """
        Create an array of profiles on a face.

        count_u: number of items horizontally along the face
        count_v: number of items vertically along the face
        spacing_u: spacing between items horizontally (in face units)
        spacing_v: spacing between items vertically (in face units)
        inset: optional inward offset along the face normal

        Returns a list of placed profiles.
        """

        placed_profiles = []

        # 1. Get face bounds
        if face == FACE.FRONT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.front_face_bounds()
            normal = (0, -1, 0)
            base_u0 = xmin
            base_v0 = zmin

        elif face == FACE.BACK:
            xmin, xmax, ymin, ymax, zmin, zmax = self.back_face_bounds()
            normal = (0, 1, 0)
            base_u0 = xmin
            base_v0 = zmin

        elif face == FACE.LEFT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.left_face_bounds()
            normal = (-1, 0, 0)
            base_u0 = ymin
            base_v0 = zmin

        elif face == FACE.RIGHT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.right_face_bounds()
            normal = (1, 0, 0)
            base_u0 = ymin
            base_v0 = zmin

        elif face == FACE.TOP:
            xmin, xmax, ymin, ymax, zmin, zmax = self.top_surface_bounds()
            normal = (0, 0, 1)
            base_u0 = xmin
            base_v0 = ymin

        elif face == FACE.BOTTOM:
            xmin, xmax, ymin, ymax, zmin, zmax = self.bottom_surface_bounds()
            normal = (0, 0, -1)
            base_u0 = xmin
            base_v0 = ymin

        else:
            raise ValueError(f"Unsupported face: {face}")

        # 2. Loop over array positions
        for iu in range(count_u):
            for iv in range(count_v):

                # Clone the profile for each instance
                p = profile.clone()

                # Compute parametric u,v in face coordinates
                u_pos = base_u0 + iu * spacing_u
                v_pos = base_v0 + iv * spacing_v

                # Convert u,v into actual placement
                # Use the existing face-placement helpers
                if face == FACE.FRONT:
                    self.place_profile_on_front_face(p,
                        u=(u_pos - xmin) / (xmax - xmin),
                        v=(v_pos - zmin) / (zmax - zmin),
                        inset=inset)

                elif face == FACE.BACK:
                    self.place_profile_on_back_face(p,
                        u=(u_pos - xmin) / (xmax - xmin),
                        v=(v_pos - zmin) / (zmax - zmin),
                        inset=inset)

                elif face == FACE.LEFT:
                    self.place_profile_on_left_face(p,
                        u=(u_pos - ymin) / (ymax - ymin),
                        v=(v_pos - zmin) / (zmax - zmin),
                        inset=inset)

                elif face == FACE.RIGHT:
                    self.place_profile_on_right_face(p,
                        u=(u_pos - ymin) / (ymax - ymin),
                        v=(v_pos - zmin) / (zmax - zmin),
                        inset=inset)

                elif face == FACE.TOP:
                    self.place_profile_on_top_surface(p,
                        u=(u_pos - xmin) / (xmax - xmin),
                        v=(v_pos - ymin) / (ymax - ymin),
                        inset=inset)

                elif face == FACE.BOTTOM:
                    self.place_profile_on_bottom_surface(p,
                        u=(u_pos - xmin) / (xmax - xmin),
                        v=(v_pos - ymin) / (ymax - ymin),
                        inset=inset)

                placed_profiles.append(p)

        return placed_profiles

    def offset_on_face(self, profile, face, du=0.0, dv=0.0):
        """
        Offset a profile along the local axes of a face.

        du: offset along the face's horizontal axis (u direction)
        dv: offset along the face's vertical axis (v direction)

        Offsets are in actual model units (mm), not parametric.
        """

        # FRONT/BACK faces lie in XZ plane
        if face in (FACE.FRONT, FACE.BACK):
            # u = X axis, v = Z axis
            profile.translate(dx=du, dy=0, dz=dv)
            return profile

        # LEFT/RIGHT faces lie in YZ plane
        if face in (FACE.LEFT, FACE.RIGHT):
            # u = Y axis, v = Z axis
            profile.translate(dx=0, dy=du, dz=dv)
            return profile

        # TOP/BOTTOM faces lie in XY plane
        if face in (FACE.TOP, FACE.BOTTOM):
            # u = X axis, v = Y axis
            profile.translate(dx=du, dy=dv, dz=0)
            return profile

        raise ValueError(f"Unsupported face: {face}")

    def scale_on_face(self, profile, face, su=1.0, sv=1.0):
        """
        Scale a profile along the local axes of a face.

        su: scale factor along the face's horizontal axis (u direction)
        sv: scale factor along the face's vertical axis (v direction)

        Scaling is done in the face's own coordinate system:
            FRONT/BACK → XZ plane
            LEFT/RIGHT → YZ plane
            TOP/BOTTOM → XY plane
        """

        # FRONT/BACK faces lie in XZ → scale in X and Z
        if face in (FACE.FRONT, FACE.BACK):
            profile.scale3d(sx=su, sy=1, sz=sv)
            return profile

        # LEFT/RIGHT faces lie in YZ → scale in Y and Z
        if face in (FACE.LEFT, FACE.RIGHT):
            profile.scale3d(sx=1, sy=su, sz=sv)
            return profile

        # TOP/BOTTOM faces lie in XY → scale in X and Y
        if face in (FACE.TOP, FACE.BOTTOM):
            profile.scale3d(sx=su, sy=sv, sz=1)
            return profile

        raise ValueError(f"Unsupported face: {face}")

    def pocket(self, profile, face=None, depth=1.0, pos=None, normal=None, rotation=0, tilt_x=0, tilt_y=0):
        """Cut a profile into the shape."""
        if not isinstance(profile, (Polygon, Profile)):
            raise TypeError("Pocket profile must be a Polygon or Profile")
        if not isinstance(profile, Profile):
            profile = Profile(profile)
        if pos is not None:
            profile.pos = pos
        if depth <= 0:
            raise ValueError("Pocket depth must be positive") 
        if face is None:
            face = FACE.TOP            
        if normal is None:
            normal = self.default_normal_for_face(face)
        self.features.append(
            Pocket(
                profile=profile, 
                depth=depth, 
                normal = normal, 
                pos=profile.pos, 
                rotation=rotation, 
                tilt_x=tilt_x, 
                tilt_y=tilt_y, 
                face=face
            )
        )
        return self
 
    def pocket_on_face(self, profile, face=None, u=0.5, v=0.5, depth=1.0, pos=None, inset=0.0):
        print("POCKET ON FACE:")
        print("  Shape receiving pocket:", self)
        print("  Face:", face)
        print("  u, v:", u, v)

        """
        Place a 2D profile on the requested face and create a pocket
        (extrusion inward along the face normal).
        """
        profile = profile.copy()
        if not isinstance(profile, Profile):
            profile = Profile(profile)
        region = profile.regions[0]
        poly = region[0]

        # Apply pos if provided
        if pos is not None:
            profile.pos = pos

        if face is None:
            face = FACE.TOP

        # Center the profile
        xs = [p[0] for p in poly.points]
        ys = [p[1] for p in poly.points]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        cx = (xmin + xmax) / 2
        cy = (ymin + ymax) / 2
        profile.translate3d(-cx, -cy, 0)
        # Dispatch to correct face-placement function
        if face == FACE.FRONT:
            placed = self.place_profile_on_front_face(profile, u=u, v=v, inset=inset)
            normal = (0, -1, 0)

        elif face == FACE.BACK:
            profile.rotate3d(180, 0, 1, 0)
            placed = self.place_profile_on_back_face(profile, u=u, v=v, inset=inset)
            normal = (0, 1, 0)

        elif face == FACE.LEFT:
            profile.rotate3d(180, 0, 1, 0)
            placed = self.place_profile_on_left_face(profile, u=u, v=v, inset=inset)
            normal = (-1, 0, 0)

        elif face == FACE.RIGHT:
            placed = self.place_profile_on_right_face(profile, u=u, v=v, inset=inset)
            normal = (1, 0, 0)

        elif face == FACE.TOP:
            placed = self.place_profile_on_top_face(profile, u=u, v=v, inset=inset)
            normal = (0, 0, 1)

        elif face == FACE.BOTTOM:
            placed = self.place_profile_on_bottom_face(profile, u=u, v=v, inset=inset)
            normal = (0, 0, -1)

        else:
            raise ValueError(f"Unsupported face: {face}")

        # Extrude inward along the face normal
        self.pocket(placed, depth=depth, normal=normal, face=face)

        return placed

    def rect_pocket(self, length, width, pos=(0, 0), depth=1, rotation=0, tilt_x=0, tilt_y=0, face=FACE.TOP):
        """Add a rectangular pocket centred at pos."""

        x, y = pos

        profile = Polygon([
            (-length / 2 + x, -width / 2 + y),
            ( length / 2 + x, -width / 2 + y),
            ( length / 2 + x,  width / 2 + y),
            (-length / 2 + x,  width / 2 + y)
        ])

        return self.pocket(profile, depth, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)   

    def circle_pocket(self, radius, pos=(0, 0), depth=1, segments=32, rotation=0, tilt_x=0, tilt_y=0, face=FACE.TOP):
        """Add a circular pocket centred at pos."""

        from .helpers import circle

        profile = circle(
            radius,
            segments=segments,
            pos=pos
        )

        return self.pocket(profile, depth, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def ellipse_pocket(self, rx, ry, pos=(0, 0), depth=1, segments=32, rotation=0, tilt_x=0, tilt_y=0, face=FACE.TOP):
        """Add an elliptical pocket centred at pos."""

        from .helpers import ellipse

        profile = ellipse(
            rx,
            ry,
            segments=segments,
            pos=pos
        )

        return self.pocket(profile, depth, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def slot_pocket(self, length, width, pos=(0, 0), angle=0, depth=1, segments=16, rotation=0, tilt_x=0, tilt_y=0, face=FACE.TOP):
        """Add a slot-shaped pocket centred at pos."""
        from .helpers import slot
        profile = slot(
            length,
            width,
            pos=pos,
            angle=angle,
            segments=segments
        )

        return self.pocket(profile, depth, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def default_normal_for_face(self, face):
        if face == FACE.TOP: return (0, 0, 1)
        if face == FACE.BOTTOM: return (0, 0, -1)
        if face == FACE.FRONT: return (0, -1, 0)
        if face == FACE.BACK: return (0, 1, 0)
        if face == FACE.LEFT: return (-1, 0, 0)
        if face == FACE.RIGHT: return (1, 0, 0)
        raise ValueError("Unknown face")

    def boss(self, profile, face=None, height=1.0, pos=None, normal = None, rotation=0, tilt_x=0, tilt_y=0):
        """Add a profile to the shape."""
        if not isinstance(profile, (Polygon, Profile)):
            raise TypeError("Boss profile must be a Polygon or Profile")
        if not isinstance(profile, Profile):
            profile = Profile(profile)
        if pos is not None:
            profile.pos = pos
        if height <= 0:
            raise ValueError("Boss height must be positive") 
        if face is None:
            face = FACE.TOP            
        if normal is None:
            normal = self.default_normal_for_face(face)
        self.features.append(
            Boss(
                profile=profile, 
                height=height,     
                normal=normal,
                pos=profile.pos,
                rotation=rotation,
                tilt_x=tilt_x,
                tilt_y=tilt_y,
                face=face
            )
        )

        return self
 
    def boss_on_face(self, profile, face=None, u=0.5, v=0.5, height=1.0, pos=None, inset=0.0):
        """
        Place a 2D profile on the requested face and create a boss
        (extrusion outward along the face normal).

        face: FACE enum (TOP, BOTTOM, FRONT, BACK, LEFT, RIGHT)
        u, v: parametric coordinates on the face
        height: extrusion height
        inset: move slightly inward along face normal
        """
        profile = profile.copy()
        region = profile.regions[0]
        poly = region[0]
        # Apply pos if provided
        if pos is not None:
            profile.pos = pos
        if face is None:
            face = FACE.TOP            
        xs = [p[0] for p in poly.points]
        ys = [p[1] for p in poly.points]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        cx = (xmin + xmax) / 2
        cy = (ymin + ymax) / 2
        profile.translate3d(-cx, -cy, 0)
        # 1. Dispatch to the correct face-placement function
        if face == FACE.FRONT:
            placed = self.place_profile_on_front_face(profile, u=u, v=v, inset=inset)
            normal = (0, -1, 0)
        elif face == FACE.BACK:
            profile.rotate3d(180, 0, 1, 0)
            placed = self.place_profile_on_back_face(profile, u=u, v=v, inset=inset)
            normal = (0, 1, 0)

        elif face == FACE.LEFT:
            profile.rotate3d(180, 0, 1, 0 )         # rotate 180° around Z-axis       was 90,0,0,1      
            placed = self.place_profile_on_left_face(profile, u=u, v=v, inset=inset)
            normal = (-1, 0, 0)

        elif face == FACE.RIGHT:
            placed = self.place_profile_on_right_face(profile, u=u, v=v, inset=inset)
            normal = (1, 0, 0)

        elif face == FACE.TOP:
            placed = self.place_profile_on_top_face(profile, u=u, v=v, inset=inset)
            normal = (0, 0, 1)

        elif face == FACE.BOTTOM:
            placed = self.place_profile_on_bottom_face(profile, u=u, v=v, inset=inset)
            normal = (0, 0, -1)

        else:
            raise ValueError(f"Unsupported face: {face}")
       
        # 2. Extrude outward along the face normal
        self.boss(placed, height=height, normal=normal, face=face)

        return placed

    def rect_boss(
        self, 
        length, 
        width, 
        pos=(0, 0), 
        height=1, 
        rotation=0, 
        tilt_x=0, 
        tilt_y=0, 
        face=FACE.TOP):
        """Add a rectangular boss centred at pos."""

        x, y = pos

        profile = Polygon([
            (x - length / 2, y - width / 2),
            (x + length / 2, y - width / 2),
            (x + length / 2, y + width / 2),
            (x - length / 2, y + width / 2)
        ])

        return self.boss(profile, height, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def circle_boss(
        self, 
        radius, 
        pos=(0, 0), 
        height=1, 
        segments=32, 
        rotation=0, 
        tilt_x=0, 
        tilt_y=0, 
        face=FACE.TOP):
        """Add a circular boss centred at pos."""

        from .helpers import circle

        profile = circle(
            radius,
            segments=segments,
            pos=pos
        )

        return self.boss(profile, height, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def ellipse_boss(
        self, 
        rx, 
        ry, 
        pos=(0, 0), 
        height=1, 
        segments=32, 
        rotation=0, 
        tilt_x=0, 
        tilt_y=0, 
        face=FACE.TOP):
        """Add an elliptical boss centred at pos."""

        from .helpers import ellipse

        profile = ellipse(
            rx,
            ry,
            segments=segments,
            pos=pos
        )

        return self.boss(profile, height, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def slot_boss(
        self, 
        length, 
        width,
        pos=(0, 0), 
        angle=0, 
        height=1, 
        segments=16, 
        rotation=0, 
        tilt_x=0, 
        tilt_y=0, 
        face=FACE.TOP):
        """Add a slot-shaped boss centred at pos."""

        from .helpers import slot

        profile = slot(
            length,
            width,
            pos=pos,
            angle=angle,
            segments=segments
        )

        return self.boss(profile, height, pos, rotation=rotation, tilt_x=tilt_x, tilt_y=tilt_y, face=face)

    def max_top_z_in_polygon(self, profile):
        """Return the highest top-surface Z covered by a profile."""
        if isinstance(profile, Polygon):
            regions = [[profile]]
        else:
            regions = profile.regions

        maximum_z = None

        for region in regions:

            profile = region[0]

            profile_points = [
                (x, y, z)
                for x, y, z in profile.points
            ]

            profile_edges = [
                (profile_points[i],
                 profile_points[(i + 1) % len(profile_points)])
                for i in range(len(profile_points))
            ]

            for indexes in self.polygon.triangulate():

                a = self.top_points[indexes[0]]
                b = self.top_points[indexes[1]]
                c = self.top_points[indexes[2]]

                candidates = []

                # Top triangle vertices inside the profile
                for p in (a, b, c):
                    if self._point_in_polygon_xy(
                        p[0],
                        p[1],
                        profile_points
                    ):
                        candidates.append(p)

                # Profile vertices inside the top triangle
                for p in profile_points:
                    if self._point_in_triangle_xy(
                        p[0],
                        p[1],
                        a,
                        b,
                        c
                    ):
                        candidates.append(
                            (
                                p[0],
                                p[1],
                                self._interpolate_z(
                                    p[0], p[1], a, b, c
                                )
                            )
                        )

                # Intersections between profile edges and
                # triangle edges
                triangle_edges = (
                    (a, b),
                    (b, c),
                    (c, a)
                )

                for p1, p2 in profile_edges:
                    for t1, t2 in triangle_edges:

                        intersection = self._segment_intersection_2d(
                            p1,
                            p2,
                            t1,
                            t2
                        )

                        if intersection is not None:
                            ix, iy = intersection

                            candidates.append(
                                (
                                    ix,
                                    iy,
                                    self._interpolate_z(
                                        ix, iy, a, b, c
                                    )
                                )
                            )

                for p in candidates:
                    if maximum_z is None or p[2] > maximum_z:
                        maximum_z = p[2]
        if maximum_z is None:
            print("DEBUG top polygon points:", self.top_points)
            print("DEBUG base polygon points:", self.polygon.points)
            print("DEBUG profile regions:")
            for region in regions:
                poly = region[0]
                print("  profile points:", poly.points)
            raise ValueError(
                "Profile does not intersect the top surface"
            )

        if maximum_z is None:
            raise ValueError(
                "Profile does not intersect the top surface"
            )

        return maximum_z    
        
    @staticmethod
    def _point_in_polygon_xy(x, y, points):
        """Return True if XY is inside a polygon."""

        inside = False

        j = len(points) - 1

        for i in range(len(points)):
            xi, yi = points[i][0], points[i][1]
            xj, yj = points[j][0], points[j][1]

            intersects = (
                (yi > y) != (yj > y)
                and x < (
                    (xj - xi) * (y - yi)
                    / (yj - yi)
                    + xi
                )
            )

            if intersects:
                inside = not inside

            j = i

        return inside

    @staticmethod
    def _segment_intersection_2d(p1, p2, q1, q2):
        """Return segment intersection XY, or None."""

        x1, y1 = p1[0], p1[1]
        x2, y2 = p2[0], p2[1]

        x3, y3 = q1[0], q1[1]
        x4, y4 = q2[0], q2[1]

        denominator = (
            (x1 - x2) * (y3 - y4)
            - (y1 - y2) * (x3 - x4)
        )

        if abs(denominator) < 1e-12:
            return None

        t = (
            (x1 - x3) * (y3 - y4)
            - (y1 - y3) * (x3 - x4)
        ) / denominator

        u = -(
            (x1 - x2) * (y1 - y3)
            - (y1 - y2) * (x1 - x3)
        ) / denominator

        if 0 <= t <= 1 and 0 <= u <= 1:
            return (
                x1 + t * (x2 - x1),
                y1 + t * (y2 - y1)
            )

        return None    
    
    def top_surface_frame(self, u, v):

        # ------------------------------------------------------------
        # CASE 1: Lofted wall → top face is NOT planar
        # ------------------------------------------------------------
        if getattr(self, "_is_loft", False):
            origin = (u, v, self.top_z)
            return origin, (1,0,0), (0,1,0), (0,0,1)

        # ------------------------------------------------------------
        # CASE 2: Extruded wall → top face IS planar
        # ------------------------------------------------------------

        # Normalize top_points into numeric 3D tuples
        pts = []
        for p in self.top_points:
            if hasattr(p, "x"):  # FreeCAD.Vector
                pts.append((p.x, p.y, p.z))
            elif len(p) == 2:    # 2D tuple
                pts.append((p[0], p[1], self.top_z))
            else:                # 3D tuple
                pts.append((p[0], p[1], p[2]))

        # Need at least 3 points to compute a normal
        if len(pts) < 3:
            origin = (u, v, max(p[2] for p in pts))
            return origin, (1,0,0), (0,1,0), (0,0,1)

        # Compute normal from first non-collinear triangle
        normal = None
        for i in range(len(pts)-2):
            p0, p1, p2 = pts[i], pts[i+1], pts[i+2]
            v1 = (p1[0]-p0[0], p1[1]-p0[1], p1[2]-p0[2])
            v2 = (p2[0]-p0[0], p2[1]-p0[1], p2[2]-p0[2])
            nx = v1[1]*v2[2] - v1[2]*v2[1]
            ny = v1[2]*v2[0] - v1[0]*v2[2]
            nz = v1[0]*v2[1] - v1[1]*v2[0]
            L = (nx*nx + ny*ny + nz*nz)**0.5
            if L > 1e-9:  # non-collinear
                normal = (nx/L, ny/L, nz/L)
                break

        # Fallback if all points are collinear
        if normal is None:
            origin = (u, v, max(p[2] for p in pts))
            return origin, (1,0,0), (0,1,0), (0,0,1)

        # Choose x_axis as longest edge
        longest = (1,0,0)
        max_len = -1
        for i in range(len(pts)):
            j = (i+1) % len(pts)
            ex = pts[j][0] - pts[i][0]
            ey = pts[j][1] - pts[i][1]
            ez = pts[j][2] - pts[i][2]
            L = ex*ex + ey*ey + ez*ez
            if L > max_len:
                max_len = L
                longest = (ex, ey, ez)

        L = (longest[0]**2 + longest[1]**2 + longest[2]**2)**0.5
        x_axis = (longest[0]/L, longest[1]/L, longest[2]/L)

        # y_axis = normal × x_axis
        yx = normal[1]*x_axis[2] - normal[2]*x_axis[1]
        yy = normal[2]*x_axis[0] - normal[0]*x_axis[2]
        yz = normal[0]*x_axis[1] - normal[1]*x_axis[0]
        L = (yx*yx + yy*yy + yz*yz)**0.5
        y_axis = (yx/L, yy/L, yz/L)

        origin = (u, v, max(p[2] for p in pts))
        return origin, x_axis, y_axis, normal

    def bottom_surface_frame(self, x, y):
        """Return origin and local axes at the bottom surface."""

        origin = (x, y, 0.0)

        x_axis = (1.0, 0.0, 0.0)
        y_axis = (0.0, -1.0, 0.0)
        z_axis = (0.0, 0.0, -1.0)

        return (
            origin,
            x_axis,
            y_axis,
            z_axis
        ) 

    def _shape_x_range(self):
        xs = [x for (x, y, z) in self.bottom_points]
        return min(xs), max(xs)

    def _shape_y_range(self):
        ys = [y for (x, y, z) in self.bottom_points]
        return min(ys), max(ys)

    def _shape_z_range(self):
        # Bottom Z from bottom_points, top Z from top_points or top_z_value
        z_bottoms = [z for (x, y, z) in self.bottom_points]
        z_tops = [z for (x, y, z) in self.top_points]

        zmin = min(z_bottoms)
        zmax = max(z_tops)

        return zmin, zmax

    def front_face_bounds(self):
        """
        FRONT face: plane at Y = ymin (front-most).
        Horizontal axis = X
        Vertical axis   = Z
        """
        xmin, xmax = self._shape_x_range()
        ymin, ymax_y = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Front plane at ymin
        return xmin, xmax, ymin, ymin, zmin, zmax

    def back_face_bounds(self):
        """
        BACK face: plane at Y = ymax (back-most).
        Horizontal axis = X
        Vertical axis   = Z
        """
        xmin, xmax = self._shape_x_range()
        ymin_y, ymax = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Back plane at ymax
        return xmin, xmax, ymax, ymax, zmin, zmax

    def left_face_bounds(self):
        """
        LEFT face: plane at X = xmin (left-most).
        Horizontal axis = Y
        Vertical axis   = Z
        """
        xmin, xmax_x = self._shape_x_range()
        ymin, ymax = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Left plane at xmin
        return xmin, xmin, ymin, ymax, zmin, zmax

    def right_face_bounds(self):
        """
        RIGHT face: plane at X = xmax (right-most).
        Horizontal axis = Y
        Vertical axis   = Z
        """
        xmin_x, xmax = self._shape_x_range()
        ymin, ymax = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Right plane at xmax
        return xmax, xmax, ymin, ymax, zmin, zmax

    def bottom_surface_bounds(self):
        """
        BOTTOM face: plane at Z = zmin.
        Horizontal axis = X
        Vertical axis   = Y
        """
        xmin, xmax = self._shape_x_range()
        ymin, ymax = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Bottom plane at zmin
        return xmin, xmax, ymin, ymax, zmin, zmin

    def top_surface_bounds(self):
        """
        TOP face: plane at Z = zmax.
        Horizontal axis = X
        Vertical axis   = Y
        """
        xmin, xmax = self._shape_x_range()
        ymin, ymax = self._shape_y_range()
        zmin, zmax = self._shape_z_range()

        # Top plane at zmax
        return xmin, xmax, ymin, ymax, zmax, zmax

    def _surface_normal(self, pts):
        """
        Compute normal of a polygon surface using first three points.
        """
        import numpy as np

        p0 = np.array(pts[0])
        p1 = np.array(pts[1])
        p2 = np.array(pts[2])

        v1 = p1 - p0
        v2 = p2 - p0

        n = np.cross(v1, v2)
        n = n / np.linalg.norm(n)

        return tuple(n)

    def place_profile_on_top_face(self, profile, u, v, inset=0):
        origin, x_axis, y_axis, z_axis = self.top_surface_frame(u, v)
        return profile.place_in_frame(origin, x_axis, y_axis, z_axis, inset)

    def place_profile_on_bottom_face(self, profile, u, v, inset=0):
        bot_poly = self.bottom_face_polygon()
        xs = [p[0] for p in bot_poly]
        ys = [p[1] for p in bot_poly]

        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)

        x_target = xmin + u * (xmax - xmin)
        y_target = ymin + v * (ymax - ymin)

        z_bot = min(p[2] for p in self.bottom_points)
        z_target = z_bot - inset   # inset goes downward

        profile.pos = (x_target, y_target)
        return profile

    def place_profile_on_front_face(self, profile, u, v, inset=0):
        # 0. Get the actual FRONT face polygon
        front_poly = self.front_face_polygon()   # must return list of (x,y,z)

        xs = [p[0] for p in front_poly]
        zs = [p[2] for p in front_poly]

        xmin, xmax = min(xs), max(xs)
        zmin, zmax = min(zs), max(zs)
    
        # 2. Compute target position in FRONT plane
        pos1 = xmin + u * (xmax - xmin)
        pos2 = zmin + v * (zmax - zmin)

        # FRONT face has Y = 0
        #y_target = 0 + inset

        # 3. Place profile on FRONT plane
        profile.pos = (pos1, pos2)
        return profile

    def place_profile_on_back_face(self, profile, u, v, inset=0):
        back_poly = self.back_face_polygon()
        for i, p in enumerate(back_poly):
            print(i, p)
        xs = [p[0] for p in back_poly]
        zs = [p[2] for p in back_poly]

        xmin, xmax = min(xs), max(xs)
        zmin, zmax = min(zs), max(zs)

        # Flip BOTH u and v
        x_target = xmax - u * (xmax - xmin)
        z_target = zmin + v * (zmax - zmin)

        profile.pos = (x_target, z_target)
        return profile

    def place_profile_on_left_face(self, profile, u, v, inset=0):
        left_poly = self.left_face_polygon()
        ys = [p[1] for p in left_poly]
        zs = [p[2] for p in left_poly]

        ymin, ymax = min(ys), max(ys)
        zmin, zmax = min(zs), max(zs)

        y_target = ymin + u * (ymax - ymin)
        z_target = zmin + v * (zmax - zmin)

        x_left = min(p[0] for p in self.bottom_points + self.top_points)
        x_target = x_left + inset

        profile.pos = (y_target, z_target)
        return profile

    def place_profile_on_right_face(self, profile, u, v, inset=0):
        right_poly = self.right_face_polygon()
        ys = [p[1] for p in right_poly]
        zs = [p[2] for p in right_poly]

        ymin, ymax = min(ys), max(ys)
        zmin, zmax = min(zs), max(zs)

        y_target = ymin + u * (ymax - ymin)
        z_target = zmin + v * (zmax - zmin)

        x_right = max(p[0] for p in self.bottom_points + self.top_points)
        x_target = x_right + inset

        profile.pos = (y_target, z_target)
        return profile

    def text_on_face(self, text, face, u=0.5, v=0.5, height=5.0, inset=0.0,
                 font=r"C:\Windows\Fonts\arial.ttf", tracking=0, deflection=0.2):
        """
        Create a text profile and place it on the requested face.

        face: FACE enum (TOP, BOTTOM, FRONT, BACK, LEFT, RIGHT)
        u, v: parametric coordinates on the face
        height: text height
        inset: move slightly inward along face normal
        """
        from mycad.api import text_profile
        # 1. Create the text profile (core-level shell)
        profile = text_profile(
            text=text,
            height=height,
            font=font,
            tracking=tracking,
            deflection=deflection,
            x=0,
            y=0,
            angle=0
        )

        # 2. Dispatch to the correct face-placement function
        if face == FACE.FRONT:
            return self.place_profile_on_front_face(profile, u=u, v=v, inset=inset)

        elif face == FACE.BACK:
            return self.place_profile_on_back_face(profile, u=u, v=v, inset=inset)

        elif face == FACE.LEFT:
            return self.place_profile_on_left_face(profile, u=u, v=v, inset=inset)

        elif face == FACE.RIGHT:
            return self.place_profile_on_right_face(profile, u=u, v=v, inset=inset)

        elif face == FACE.TOP:
            # You already have top-surface placement logic
            return self.place_profile_on_top_surface(profile, u=u, v=v, inset=inset)

        elif face == FACE.BOTTOM:
            # You already have bottom-surface placement logic
            return self.place_profile_on_bottom_surface(profile, u=u, v=v, inset=inset)

        else:
            raise ValueError(f"Unsupported face: {face}")

    def face_coordinates(self, face, x, y, z):
        """
        Convert a world-space point (x, y, z) into local face coordinates (u, v, w).

        u: horizontal axis on the face
        v: vertical axis on the face
        w: distance along the face normal (0 = on the face)
        """

        # FRONT/BACK faces lie in XZ plane
        if face in (FACE.FRONT, FACE.BACK):
            xmin, xmax, ymin, ymax, zmin, zmax = (
                self.front_face_bounds() if face == FACE.FRONT
                else self.back_face_bounds()
            )

            # u = X axis
            u = (x - xmin) / (xmax - xmin)

            # v = Z axis
            v = (z - zmin) / (zmax - zmin)

            # w = distance along Y normal
            if face == FACE.FRONT:
                w = y - ymin   # FRONT normal = -Y
            else:
                w = ymax - y   # BACK normal = +Y

            return (u, v, w)

        # LEFT/RIGHT faces lie in YZ plane
        if face in (FACE.LEFT, FACE.RIGHT):
            xmin, xmax, ymin, ymax, zmin, zmax = (
                self.left_face_bounds() if face == FACE.LEFT
                else self.right_face_bounds()
            )

            # u = Y axis
            u = (y - ymin) / (ymax - ymin)

            # v = Z axis
            v = (z - zmin) / (zmax - zmin)

            # w = distance along X normal
            if face == FACE.LEFT:
                w = x - xmin   # LEFT normal = -X
            else:
                w = xmax - x   # RIGHT normal = +X

            return (u, v, w)

        # TOP/BOTTOM faces lie in XY plane
        if face in (FACE.TOP, FACE.BOTTOM):
            xmin, xmax, ymin, ymax, zmin, zmax = (
                self.top_surface_bounds() if face == FACE.TOP
                else self.bottom_surface_bounds()
            )

            # u = X axis
            u = (x - xmin) / (xmax - xmin)

            # v = Y axis
            v = (y - ymin) / (ymax - ymin)

            # w = distance along Z normal
            if face == FACE.TOP:
                w = z - zmax   # TOP normal = +Z
            else:
                w = zmin - z   # BOTTOM normal = -Z

            return (u, v, w)

        raise ValueError(f"Unsupported face: {face}")

    def face_bbox(self, profile, face):
        """
        Compute the bounding box of a profile in the local coordinate frame of a face.

        Returns (u_min, u_max, v_min, v_max, w_min, w_max)
        where:
            u = horizontal axis on the face
            v = vertical axis on the face
            w = distance along the face normal
        """

        u_vals = []
        v_vals = []
        w_vals = []

        # Loop through all profile points
        for region in profile.regions:
            for poly in region:
                for (x, y, z) in poly.points:
                    u, v, w = self.face_coordinates(face, x, y, z)
                    u_vals.append(u)
                    v_vals.append(v)
                    w_vals.append(w)

        return (
            min(u_vals), max(u_vals),
            min(v_vals), max(v_vals),
            min(w_vals), max(w_vals)
        )

    def snap_on_face(self, profile, face, target='center', inset=0.0):
        """
        Snap a profile to a specific location on a face.
        target options:
            'center', 'left', 'right', 'top', 'bottom', 'top-left', 'top-right', 'bottom-left', 'bottom-right'
            'mid-left', 'mid-right', 'mid-top', 'mid-bottom'
        inset: optional inward offset along the face normal.
        """
        if target == 'center':
            return(0.5, 0.5)
        # 1. Get face bounds
        if face == FACE.FRONT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.front_face_bounds()
            normal = (0, -1, 0)
            u0, u1 = xmin, xmax
            v0, v1 = zmin, zmax

        elif face == FACE.BACK:
            xmin, xmax, ymin, ymax, zmin, zmax = self.back_face_bounds()
            normal = (0, 1, 0)
            u0, u1 = xmin, xmax
            v0, v1 = zmin, zmax

        elif face == FACE.LEFT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.left_face_bounds()
            normal = (-1, 0, 0)
            u0, u1 = ymin, ymax
            v0, v1 = zmin, zmax

        elif face == FACE.RIGHT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.right_face_bounds()
            normal = (1, 0, 0)
            u0, u1 = ymin, ymax
            v0, v1 = zmin, zmax

        elif face == FACE.TOP:
            xmin, xmax, ymin, ymax, zmin, zmax = self.top_surface_bounds()
            normal = (0, 0, 1)
            u0, u1 = xmin, xmax
            v0, v1 = ymin, ymax

        elif face == FACE.BOTTOM:
            xmin, xmax, ymin, ymax, zmin, zmax = self.bottom_surface_bounds()
            normal = (0, 0, -1)
            u0, u1 = xmin, xmax
            v0, v1 = ymin, ymax

        else:
            raise ValueError(f"Unsupported face: {face}")

        # 2. Compute target u,v in face coordinates
        targets = {
            'center':       ((u0 + u1)/2, (v0 + v1)/2),
            'left':         (u0, (v0 + v1)/2),
            'right':        (u1, (v0 + v1)/2),
            'top':          ((u0 + u1)/2, v1),
            'bottom':       ((u0 + u1)/2, v0),
            'top-left':     (u0, v1),
            'top-right':    (u1, v1),
            'bottom-left':  (u0, v0),
            'bottom-right': (u1, v0),
            'mid-left':     (u0, (v0 + v1)/2),
            'mid-right':    (u1, (v0 + v1)/2),
            'mid-top':      ((u0 + u1)/2, v1),
            'mid-bottom':   ((u0 + u1)/2, v0),
        }

        if target not in targets:
            raise ValueError(f"Unsupported snap target: {target}")

        u_target, v_target = targets[target]

        # Convert to parametric u,v
        u_param = (u_target - u0) / (u1 - u0)
        v_param = (v_target - v0) / (v1 - v0)
        """
        # 3. Place profile using existing face-placement helpers
        if face == FACE.FRONT:
            self.place_profile_on_front_face(profile, u=u_param, v=v_param, inset=inset)
        elif face == FACE.BACK:
            self.place_profile_on_back_face(profile, u=u_param, v=v_param, inset=inset)
        elif face == FACE.LEFT:
            self.place_profile_on_left_face(profile, u=u_param, v=v_param, inset=inset)
        elif face == FACE.RIGHT:
            self.place_profile_on_right_face(profile, u=u_param, v=v_param, inset=inset)
        elif face == FACE.TOP:
            self.place_profile_on_top_surface(profile, u=u_param, v=v_param, inset=inset)
        elif face == FACE.BOTTOM:
            self.place_profile_on_bottom_surface(profile, u=u_param, v=v_param, inset=inset)

        return profile
        """

        return u_param, v_param
         
    def layout_on_face(self, profiles, face,
        rows=1, cols=1,
        margin_u=0.0, margin_v=0.0,
        padding_u=0.0, padding_v=0.0,
        inset=0.0,
        align='center'):
        """
        Layout multiple profiles on a face in a grid.

        profiles: list of profiles (length must be rows * cols)
        face: FACE enum
        rows, cols: grid dimensions
        margin_u, margin_v: outer margin on the face (mm)
        padding_u, padding_v: spacing between grid cells (mm)
        inset: inward offset along face normal
        align: 'center', 'top', 'bottom', 'left', 'right',
            'top-left', 'top-right', 'bottom-left', 'bottom-right'

        Returns list of placed profiles.
        """

        if len(profiles) != rows * cols:
            raise ValueError("profiles length must equal rows * cols")

        # 1. Get face bounds
        if face == FACE.FRONT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.front_face_bounds()
            u0, u1 = xmin, xmax
            v0, v1 = zmin, zmax

        elif face == FACE.BACK:
            xmin, xmax, ymin, ymax, zmin, zmax = self.back_face_bounds()
            u0, u1 = xmin, xmax
            v0, v1 = zmin, zmax

        elif face == FACE.LEFT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.left_face_bounds()
            u0, u1 = ymin, ymax
            v0, v1 = zmin, zmax

        elif face == FACE.RIGHT:
            xmin, xmax, ymin, ymax, zmin, zmax = self.right_face_bounds()
            u0, u1 = ymin, ymax
            v0, v1 = zmin, zmax

        elif face == FACE.TOP:
            xmin, xmax, ymin, ymax, zmin, zmax = self.top_surface_bounds()
            u0, u1 = xmin, xmax
            v0, v1 = ymin, ymax

        elif face == FACE.BOTTOM:
            xmin, xmax, ymin, ymax, zmin, zmax = self.bottom_surface_bounds()
            u0, u1 = xmin, xmax
            v0, v1 = ymin, ymax

        else:
            raise ValueError(f"Unsupported face: {face}")

        # 2. Compute usable region (after margins)
        u_min = u0 + margin_u
        u_max = u1 - margin_u
        v_min = v0 + margin_v
        v_max = v1 - margin_v

        # 3. Compute cell sizes
        total_u = u_max - u_min
        total_v = v_max - v_min

        cell_u = (total_u - (cols - 1) * padding_u) / cols
        cell_v = (total_v - (rows - 1) * padding_v) / rows

        placed = []

        # 4. Place each profile
        idx = 0
        for r in range(rows):
            for c in range(cols):

                p = profiles[idx].clone()
                idx += 1

                # Compute cell origin
                u_cell = u_min + c * (cell_u + padding_u)
                v_cell = v_min + r * (cell_v + padding_v)

                # Compute alignment inside cell
                if align == 'center':
                    u_target = u_cell + cell_u / 2
                    v_target = v_cell + cell_v / 2

                elif align == 'top':
                    u_target = u_cell + cell_u / 2
                    v_target = v_cell + cell_v

                elif align == 'bottom':
                    u_target = u_cell + cell_u / 2
                    v_target = v_cell

                elif align == 'left':
                    u_target = u_cell
                    v_target = v_cell + cell_v / 2

                elif align == 'right':
                    u_target = u_cell + cell_u
                    v_target = v_cell + cell_v / 2

                elif align == 'top-left':
                    u_target = u_cell
                    v_target = v_cell + cell_v

                elif align == 'top-right':
                    u_target = u_cell + cell_u
                    v_target = v_cell + cell_v

                elif align == 'bottom-left':
                    u_target = u_cell
                    v_target = v_cell

                elif align == 'bottom-right':
                    u_target = u_cell + cell_u
                    v_target = v_cell

                else:
                    raise ValueError(f"Unsupported alignment: {align}")

                # Convert to parametric u,v
                u_param = (u_target - u0) / (u1 - u0)
                v_param = (v_target - v0) / (v1 - v0)

                # Place using existing helpers
                if face == FACE.FRONT:
                    self.place_profile_on_front_face(p, u=u_param, v=v_param, inset=inset)
                elif face == FACE.BACK:
                    self.place_profile_on_back_face(p, u=u_param, v=v_param, inset=inset)
                elif face == FACE.LEFT:
                    self.place_profile_on_left_face(p, u=u_param, v=v_param, inset=inset)
                elif face == FACE.RIGHT:
                    self.place_profile_on_right_face(p, u=u_param, v=v_param, inset=inset)
                elif face == FACE.TOP:
                    self.place_profile_on_top_surface(p, u=u_param, v=v_param, inset=inset)
                elif face == FACE.BOTTOM:
                    self.place_profile_on_bottom_surface(p, u=u_param, v=v_param, inset=inset)

                placed.append(p)

        return placed
          
    def front_face_polygon(self):
        """
        Return the FRONT face polygon as 4 points:
        bottom-left, bottom-right, top-right, top-left.
        """

        # FRONT wall Y coordinate
        y_front = min(p[1] for p in self.bottom_points)

        # bottom edge points at FRONT
        bottom_front = [p for p in self.bottom_points if abs(p[1] - y_front) < 1e-6]

        # top edge points at FRONT
        top_front = [p for p in self.top_points if abs(p[1] - y_front) < 1e-6]

        # Sort bottom and top edges by X
        bottom_front.sort(key=lambda p: p[0])
        top_front.sort(key=lambda p: p[0])

        # Construct polygon in order
        return [
            bottom_front[0],   # bottom-left
            bottom_front[-1],  # bottom-right
            top_front[-1],     # top-right
            top_front[0]       # top-left
        ]
          
    def back_face_polygon(self):
        y_back = max(p[1] for p in self.bottom_points + self.top_points)

        bottom_back = [p for p in self.bottom_points if abs(p[1] - y_back) < 1e-6]
        top_back    = [p for p in self.top_points    if abs(p[1] - y_back) < 1e-6]

        bottom_back.sort(key=lambda p: p[0])
        top_back.sort(key=lambda p: p[0])

        return [
            bottom_back[0],   # bottom-left
            bottom_back[-1],  # bottom-right
            top_back[-1],     # top-right
            top_back[0]       # top-left
        ]
  
    def left_face_polygon(self):
        x_left = min(p[0] for p in self.bottom_points + self.top_points)

        bottom_left = [p for p in self.bottom_points if abs(p[0] - x_left) < 1e-6]
        top_left    = [p for p in self.top_points    if abs(p[0] - x_left) < 1e-6]

        bottom_left.sort(key=lambda p: p[2])
        top_left.sort(key=lambda p: p[2])

        return [
            bottom_left[0],   # bottom-front
            bottom_left[-1],  # bottom-back
            top_left[-1],     # top-back
            top_left[0]       # top-front
        ]
 
    def right_face_polygon(self):
        x_right = max(p[0] for p in self.bottom_points + self.top_points)

        bottom_right = [p for p in self.bottom_points if abs(p[0] - x_right) < 1e-6]
        top_right    = [p for p in self.top_points    if abs(p[0] - x_right) < 1e-6]

        bottom_right.sort(key=lambda p: p[2])
        top_right.sort(key=lambda p: p[2])

        return [
            bottom_right[0],   # bottom-front
            bottom_right[-1],  # bottom-back
            top_right[-1],     # top-back
            top_right[0]       # top-front
        ]
 
    def top_face_polygon(self):
        z_top = max(p[2] for p in self.top_points)
        pts = [p for p in self.top_points if abs(p[2] - z_top) < 1e-6] # all points on the top face
        pts.sort(key=lambda p: (p[1], p[0]))                           # sort by X, then Y to get a consistent loop
        if len(pts) != 4:                                              # assume four corners
            raise RuntimeError("Unexpected number of top face points") # assume four corners
        return [pts[0], pts[1], pts[3], pts[2]]
        
    def bottom_face_polygon(self):
        z_bot = min(p[2] for p in self.bottom_points)
        pts = [p for p in self.bottom_points if abs(p[2] - z_bot) < 1e-6]
        if len(pts) != 4:
            raise RuntimeError("Unexpected number of bottom face points")
        pts.sort(key=lambda p: (p[1], p[0]))                            # sort by Y then X
        return [pts[0], pts[1], pts[3], pts[2]]                         # front-left, front-right, back-right, back-left

    def _all_points_world(self):
        """Return all bottom and top points with all transforms applied."""
        pts = self.bottom_points + self.top_points

        # Apply transforms in order
        for tr in self.transforms:
            pts = [tr.apply_to_point(p) for p in pts]

        return pts

    def min_x(self):
        pts = self._all_points_world()
        return min(p[0] for p in pts)

    def max_x(self):
        pts = self._all_points_world()
        return max(p[0] for p in pts)

    def min_y(self):
        pts = self._all_points_world()
        return min(p[1] for p in pts)

    def max_y(self):
        pts = self._all_points_world()
        return max(p[1] for p in pts)

    def min_z(self):
        pts = self._all_points_world()
        return min(p[2] for p in pts)

    def max_z(self):
        pts = self._all_points_world()
        return max(p[2] for p in pts)

    def left_face_x(self):
        return self.min_x()

    def right_face_x(self):
        return self.max_x()

    def front_face_y(self):
        return self.min_y()

    def back_face_y(self):
        return self.max_y()

    def bottom_face_z(self):
        return self.min_z()

    def top_face_z(self):
        return self.max_z()
   
    def set_loft(self, bottom_pts, top_pts):
        
        # Store loft intent
        self._is_loft = True

        if polygon_area_2d(bottom_pts) < 0:# Fix winding for bottom
            bottom_pts = list(reversed(bottom_pts))
        self.loft_bottom = bottom_pts      # remember loft bottom
        self.bottom_points = bottom_pts    # Replace bottom point lists
        self.bottom_z = 0                  # Lofted shapes always start at Z=0
        self.polygon = Polygon(bottom_pts) # Replace footprint polygon

        if polygon_area_2d(top_pts) < 0:   # Fix winding for top
            top_pts = list(reversed(top_pts))
        self.loft_top = top_pts            # remember loft top
        self.top_points = top_pts          # Replace top point lists
             
        return self

    def copy(self):
        # Create a new Shape with a copy of the polygon
        new = Shape(self.polygon.copy())

        # Copy bottom and top points
        new.bottom_points = self.bottom_points.copy()
        new.top_points = self.top_points.copy()

        # Copy features (deep copy)
        new.features = [f.copy() for f in self.features] if hasattr(self.features[0], "copy") else list(self.features)

        # Copy transforms
        new.transforms = list(self.transforms)

        # Copy loft data
        new.loft_bottom = self.loft_bottom
        new.loft_top = self.loft_top

        # Copy Z values
        new.top_z_value = self.top_z_value
        new.bottom_z = self.bottom_z

        return new
