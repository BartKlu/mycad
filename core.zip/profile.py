# mycad/core/profile.py

import math
import copy
from .polygon import Polygon


class Profile:
    """
    A 2D profile consisting of one or more regions.

    Each region is:
        [outer_polygon, hole_polygon, hole_polygon, ...]

    The first polygon is the outer boundary.
    Remaining polygons are holes.

    The constructor Profile(outer, holes) is retained for
    backward compatibility and creates one region.
    """

    def __init__(self, outer, holes=None):
        if not isinstance(outer, Polygon):
            raise TypeError("Profile outer boundary must be a Polygon")

        if holes is None:
            holes = []

        if not isinstance(holes, (list, tuple)):
            raise TypeError("Profile holes must be a list or tuple of Polygons")

        for hole in holes:
            if not isinstance(hole, Polygon):
                raise TypeError("Profile holes must be Polygons")

        outer = outer.copy()
        holes = [hole.copy() for hole in holes]

        self.regions = [[outer] + holes]
        self.backend_data = {}
        self.pos = (0, 0)
        self.rotation = 0
        self.tilt_x = 0
        self.tilt_y = 0
        self.face = None
    @classmethod
    def from_regions(cls, regions):
        """
        Create a Profile from multiple regions.
        Each region is a list or tuple:
            [outer_polygon, hole_polygon, ...]
        The first polygon is the outer boundary.
        """
        if not isinstance(regions, (list, tuple)):
            raise TypeError("Profile regions must be a list or tuple")
        if not regions:
            raise ValueError("Profile must contain at least one region")
        # Use the first region to initialize the object properly
        outer = regions[0][0].copy()
        holes = [poly.copy() for poly in regions[0][1:]]
        # This calls __init__ and sets pos, rotation, tilt_x, tilt_y, face, backend_data
        obj = cls(outer, holes)
        # Now overwrite regions with the full multi-region structure
        obj.regions = [
            [poly.copy() for poly in region]
            for region in regions
        ]
        return obj

    @property
    def outer(self):
        """Return the outer polygon of the single region."""

        if len(self.regions) != 1:
            raise ValueError(
                "Profile has multiple regions; outer is ambiguous"
            )

        return self.regions[0][0]

    @property
    def holes(self):
        """Return the holes of the single region."""

        if len(self.regions) != 1:
            raise ValueError(
                "Profile has multiple regions; holes are ambiguous"
            )

        return self.regions[0][1:]

    def set_backend_data(self, name, data):
        self.backend_data[name] = data

    def get_backend_data(self, name):
        return self.backend_data.get(name)
               
    def rotate2d(self, angle_deg):
        a = math.radians(angle_deg)
        ca = math.cos(a)
        sa = math.sin(a)
        for region in self.regions:
            for poly in region:
                new_points = []
                for (x, y, z) in poly.points:
                    xr = x * ca - y * sa
                    yr = x * sa + y * ca
                    new_points.append((xr, yr, z))
                poly.points = new_points
        return self
   
    def rotate3d(self, angle_degrees, ax, ay, az):
        angle = math.radians(angle_degrees)
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        # Normalize axis
        length = math.sqrt(ax*ax + ay*ay + az*az)
        if length == 0:
            raise ValueError("Rotation axis cannot be zero")
        ax /= length
        ay /= length
        az /= length
        # Rodrigues' rotation formula
        for region in self.regions:
            for poly in region:
                new_points = []
                for (x, y, z) in poly.points:
                    # Compute rotated coordinates
                    rx = (cos_a + ax*ax*(1-cos_a))*x + (ax*ay*(1-cos_a) - az*sin_a)*y + (ax*az*(1-cos_a) + ay*sin_a)*z
                    ry = (ay*ax*(1-cos_a) + az*sin_a)*x + (cos_a + ay*ay*(1-cos_a))*y + (ay*az*(1-cos_a) - ax*sin_a)*z
                    rz = (az*ax*(1-cos_a) - ay*sin_a)*x + (az*ay*(1-cos_a) + ax*sin_a)*y + (cos_a + az*az*(1-cos_a))*z
                    new_points.append((rx, ry, rz))
                poly.points = new_points
        return self
    
    def translate(self, dx=0, dy=0, dz=0):
        for region in self.regions:
            for poly in region:
                new_points = []
                for (x, y, z) in poly.points:
                    new_points.append((x + dx, y + dy, z + dz))
                poly.points = new_points
        return self

    def translate3d(self, dx=0, dy=0, dz=0):
        """
        Translate all polygons in this profile in 3D.
        """
        for region in self.regions:
            for poly in region:
                new_points = []
                for (x, y, z) in poly.points:
                    new_points.append((x + dx, y + dy, z + dz))
                poly.points = new_points
        return self

    def copy(self):
        new_regions = []
        for region in self.regions:
            new_region = []
            for poly in region:
                # Strip Z from points
                pts2d = [(x, y) for (x, y, z) in poly.points]
                new_poly = Polygon(pts2d)
                new_region.append(new_poly)
            new_regions.append(new_region)

        new_profile = Profile.__new__(Profile)
        new_profile.regions = new_regions
        new_profile.backend_data = dict(self.backend_data)
        return new_profile

    def place_in_frame(self, origin, x_axis, y_axis, z_axis, inset=0.0):
        """
        Place this profile into a 3D surface frame.

        origin: (x, y, z)
        x_axis, y_axis, z_axis: unit vectors defining the surface frame
        inset: optional offset along z_axis (positive inward)
        """

        # Apply inset along the surface normal
        ox = origin[0] + inset * z_axis[0]
        oy = origin[1] + inset * z_axis[1]
        oz = origin[2] + inset * z_axis[2]

        # Transform each point in the profile
        for region in self.regions:
            for poly in region:
                new_points = []
                for (px, py, pz) in poly.points:
                    # Convert local (px, py, pz) into world coordinates
                    wx = ox + px * x_axis[0] + py * y_axis[0] + pz * z_axis[0]
                    wy = oy + px * x_axis[1] + py * y_axis[1] + pz * z_axis[1]
                    wz = oz + px * x_axis[2] + py * y_axis[2] + pz * z_axis[2]
                    new_points.append((wx, wy, wz))
                poly.points = new_points

        # Update profile position
        self.pos = (ox, oy, oz)

        return self
