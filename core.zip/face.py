# mycad/core/face.py
#
from enum import Enum


class FACE(Enum):
    TOP = "top"
    BOTTOM = "bottom"
    FRONT = "front"
    BACK = "back"
    LEFT = "left"
    RIGHT = "right"