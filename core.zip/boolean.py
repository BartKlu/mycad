# mycad/core/boolean.py

import math

from .transform import Transform


class BooleanShape:
    def __init__(self, operation, shape_a, shape_b):
        if operation not in ("cut", "fuse"):
            raise ValueError(
                f"Unknown Boolean operation: {operation}"
            )

        self.operation = operation
        self.shape_a = shape_a
        self.shape_b = shape_b

        # Rigid transformations, in the order requested.
        self.transforms = []

    def translate(self, dx=0, dy=0, dz=0):
        """Record a translation to be applied at build time."""

        self.transforms.append(
            Transform.translate(dx, dy, dz)
        )

        return self

    def rotate(self, angle, x=0, y=0, z=0):
        """Record a clockwise rotation around a point on the Z axis."""

        self.transforms.append(
            Transform.rotate_z(angle, x, y, z)
        )

        return self
        
    def build(self):
        """Build the Boolean result."""

        if self.operation == "cut":
            from ..freecad.builder import boolean_cut

            result = boolean_cut(
                self.shape_a,
                self.shape_b
            )

        elif self.operation == "fuse":
            from ..freecad.builder import boolean_fuse

            result = boolean_fuse(
                self.shape_a,
                self.shape_b
            )

        else:
            raise ValueError(
                f"Unknown Boolean operation: {self.operation}"
            )

        from ..freecad.builder import apply_transforms

        return apply_transforms(
            result,
            self.transforms
        )

    def cut(self, other):
        """Subtract another object from this result."""

        return BooleanShape(
            "cut",
            self,
            other
        )

    def fuse(self, other):
        
        """Fuse another object with this result."""

        return BooleanShape(
            "fuse",
            self,
            other
        )
                
    def bounds(self):
        """Return an axis-aligned bounding box for the Boolean result."""

        from .bounds import Bounds

        bounds_a = self.shape_a.bounds()
        bounds_b = self.shape_b.bounds()

        if self.operation == "fuse":
            bounds = bounds_a.union(bounds_b)

        elif self.operation == "cut":
            # The result cannot extend outside shape_a.
            bounds = bounds_a

        else:
            raise ValueError(
                f"Unknown Boolean operation: {self.operation}"
            )

        return bounds.transformed(self.transforms)    