# mycad/core/helpers.py

import math

from .polygon import Polygon

def rectangle(width, depth, *, height=None):
    """Create a rectangular Polygon or Shape.

    Without height, returns a Polygon.
    With height, returns a Shape with the specified top height.
    """

    if width <= 0:
        raise ValueError("Rectangle width must be positive")

    if depth <= 0:
        raise ValueError("Rectangle depth must be positive")

    polygon = Polygon([
        (0, 0),
        (width, 0),
        (width, depth),
        (0, depth)
    ])

    if height is None:
        return polygon
        
    from .shape import Shape
    return Shape(polygon).top_z(height)

def circle(radius, segments=32, pos=(0, 0)):
    """Create a circular Polygon centred at pos."""

    if radius <= 0:
        raise ValueError("Radius must be positive")

    if segments < 3:
        raise ValueError("Circle must have at least 3 segments")

    x, y = pos

    points = []

    for i in range(segments):
        angle = 2 * math.pi * i / segments

        points.append(
            (
                x + radius * math.cos(angle),
                y + radius * math.sin(angle)
            )
        )

    return Polygon(points)

def ellipse(rx, ry, segments=32, pos=(0, 0), *, height=None):
    
    """Create an elliptical Polygon or Shape."""

    if rx <= 0 or ry <= 0:
        raise ValueError("Ellipse radii must be positive")

    if segments < 3:
        raise ValueError("An ellipse requires at least 3 segments")

    x0, y0 = pos

    points = []

    for i in range(segments):
        angle = 2 * math.pi * i / segments
        x = x0 + rx * math.cos(angle)
        y = y0 + ry * math.sin(angle)
        points.append((x, y))

    polygon = Polygon(points)

    if height is None:
        return polygon

    from .shape import Shape
    return Shape(polygon).top_z(height)

def centered_rectangle(length, width, pos=(0, 0)):
    """Create a rectangular Polygon centred at pos."""

    x, y = pos

    return Polygon([
        (x - length / 2, y - width / 2),
        (x + length / 2, y - width / 2),
        (x + length / 2, y + width / 2),
        (x - length / 2, y + width / 2)
    ])    
    
def slot(length, width, pos=(0, 0), angle=0, segments=16):
    """Create a slot-shaped Polygon.

    Length is the overall length including the rounded ends.
    Width is the overall width.
    pos is the centre of the slot.
    Positive angle is clockwise viewed from +Z.
    """

    if length <= 0:
        raise ValueError("Slot length must be positive")

    if width <= 0:
        raise ValueError("Slot width must be positive")

    if length < width:
        raise ValueError("Slot length must be at least its width")

    if segments < 2:
        raise ValueError("Slot requires at least 2 segments per end")

    radius = width / 2
    straight_half = (length - width) / 2

    points = []

    # Right-hand semicircle.
    # Start at the bottom of the right end and travel CCW
    # around the outside to the top.
    for i in range(segments + 1):
        a = -math.pi / 2 + math.pi * i / segments

        points.append((
            straight_half + radius * math.cos(a),
            radius * math.sin(a)
        ))

    # Left-hand semicircle.
    # Continue from the top of the left end around to the bottom.
    for i in range(segments + 1):
        a = math.pi / 2 + math.pi * i / segments

        points.append((
            -straight_half + radius * math.cos(a),
            radius * math.sin(a)
        ))

    # Rotate and translate the profile.
    radians = math.radians(-angle)
    cos_a = math.cos(radians)
    sin_a = math.sin(radians)

    x0, y0 = pos

    transformed = []

    for x, y in points:
        xr = x * cos_a - y * sin_a
        yr = x * sin_a + y * cos_a

        transformed.append((xr + x0, yr + y0))

    return Polygon(transformed)    
    
def text_profile(text, height=20, font=r"C:\Windows\Fonts\arial.ttf", tracking=0, deflection=0.2, x=0, y=0, angle=0):
    from ..freecad.text import profile_text
    return profile_text(text=text, height=height, font=font, tracking=tracking, deflection=deflection, x=x, y=y, angle=angle)