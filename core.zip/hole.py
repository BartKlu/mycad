# mycad/core/hole.py

import math

class Hole:
    def __init__(self, x, y, diameter, depth=None, direction=(0, 0, -1), z=None, name=None):
        if diameter <= 0:
            raise ValueError("Hole diameter must be positive")

        if depth is not None and depth <= 0:
            raise ValueError("Hole depth must be positive")

        if len(direction) != 3:
            raise ValueError("Hole direction must have 3 components")

        dx, dy, dz = direction

        length = math.sqrt(
            dx * dx +
            dy * dy +
            dz * dz
        )

        if length == 0:
            raise ValueError("Hole direction cannot be zero")

        # Normalise direction
        self.direction = (
            dx / length,
            dy / length,
            dz / length
        )

        self.x = float(x)
        self.y = float(y)
        self.z = z
        self.diameter = float(diameter)
        self.depth = None if depth is None else float(depth)
        self.name = "no name" if name is None else name
        