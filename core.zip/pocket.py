# mycad/core/pocket.py
#

from .polygon import Polygon
from .profile import Profile
from .face import FACE

class Pocket:
    """A pocket feature: profile cut into a surface."""

    def __init__(self, profile, depth, normal = None, pos=None, rotation=0, tilt_x=0, tilt_y=0, face=FACE.TOP):
        if depth <= 0:
            raise ValueError("Pocket depth must be positive")
        if isinstance(profile, Polygon):
            profile = Profile(profile)
        if not isinstance(profile, Profile):
            raise TypeError("Pocket profile must be a Polygon or Profile")
        if not isinstance(face, FACE):
            raise TypeError("Pocket face must be a FACE value")            
        if pos is not None:
            if len(pos) == 2:
                pos = (float(pos[0]), float(pos[1]), 0.0)
            elif len(pos) == 3:
                pos = (float(pos[0]), float(pos[1]), float(pos[2]))
            else:
                raise ValueError("Pocket position must be a 2D or 3D tuple")
        self.profile = profile
        self.depth = float(depth)
        self.normal = normal
        self.pos = pos
        self.rotation = float(rotation)
        self.tilt_x = float(tilt_x)
        self.tilt_y = float(tilt_y)
        self.face = face
        # Backend data storage (must exist BEFORE set_backend_data calls)
        self.backend_data = {}
        self.set_backend_data("top_surface_frame", None)
        self.set_backend_data("bottom_surface_frame", None)
        self.set_backend_data("front_surface_frame", None)
        self.set_backend_data("back_surface_frame", None)
        self.set_backend_data("left_surface_frame", None)
        self.set_backend_data("right_surface_frame", None)
        
    # Backend data helpers (same API as Profile and Boss)
    def set_backend_data(self, name, data):
        self.backend_data[name] = data

    def get_backend_data(self, name):
        return self.backend_data.get(name)
