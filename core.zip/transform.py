# mycad/core/transform.py

import math

class Transform:
    """A single rigid transformation."""

    def __init__(self, kind, *values):
        self.kind = kind
        self.values = tuple(float(v) for v in values)

    @classmethod
    def translate(cls, dx=0, dy=0, dz=0):
        return cls("translate", dx, dy, dz)

    @classmethod
    def rotate_z(cls, angle, x=0, y=0, z=0):
        return cls("rotate_z", angle, x, y, z)
        
    def apply_to_point(self, p):
        x, y, z = p

        if self.kind == "translate":
            dx, dy, dz = self.values
            return (x + dx, y + dy, z + dz)

        elif self.kind == "rotate_z":
            angle, cx, cy, cz = self.values

            # shift to rotation center
            x -= cx
            y -= cy
            z -= cz

            # clockwise rotation (your convention)
            ca = math.cos(-angle)
            sa = math.sin(-angle)

            xr = x * ca - y * sa
            yr = x * sa + y * ca
            zr = z

            # shift back
            return (xr + cx, yr + cy, zr + cz)

        else:
            raise ValueError(f"Unknown transform type: {self.kind}")
        