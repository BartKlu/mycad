# mycad/core/shape.py
from ..freecad.builder import make_solid


class Shape:
    def __init__(self, polygon):
        # Make our own copy of the polygon
        self.polygon = polygon.copy()

        # Bottom points are the polygon points
        self.bottom_points = self.polygon.points.copy()

        # Initially the top is identical to the bottom
        self.top_points = self.bottom_points.copy()

    @property
    def count(self):
        return len(self.bottom_points)

    def top_z(self, z):
        """
        Set the Z value of all top points, or set individual Z values
        from a list or tuple.
        """

        if isinstance(z, (int, float)):
            self.top_points = [
                (x, y, float(z))
                for x, y, _ in self.top_points
            ]

        else:
            if len(z) != self.count:
                raise ValueError(
                    "Number of top Z values must match polygon point count"
                )

            self.top_points = [
                (x, y, float(zi))
                for (x, y, _), zi in zip(self.top_points, z)
            ]

        return self
        
    def slant(self, dx=0, dy=0):
        """Move all top points by dx and dy."""

        self.top_points = [
            (x + dx, y + dy, z)
            for x, y, z in self.top_points
        ]

    def build(self):
        return make_solid(self)