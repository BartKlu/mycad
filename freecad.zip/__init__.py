# mycad/__init__.py
#
# Public API re‑exports.   Users import from CAD

