# mycad/freecad/text.py
#
import math
import FreeCAD
import Draft
import Part

from ..core.polygon import Polygon
from ..core.profile import Profile


DEFAULT_DEFLECTION = 0.2


def _wire_to_polygon(wire, deflection):
    """Convert a FreeCAD wire into a MyCAD Polygon.

    MyCAD polygons are always stored counter-clockwise.
    """

    points = []
    edges = Part.sortEdges(wire.Edges)[0]

    for edge in edges:
        edge_points = edge.discretize(Deflection=deflection)

        # Adjacent edges share their endpoint.
        if points:
            edge_points = edge_points[1:]

        for point in edge_points:
            points.append(
                (point.x, point.y, point.z)
            )

    # The final point normally duplicates the first.
    if len(points) > 1:
        first = points[0]
        last = points[-1]

        if (
            abs(first[0] - last[0]) < 1e-9
            and abs(first[1] - last[1]) < 1e-9
            and abs(first[2] - last[2]) < 1e-9
        ):
            points.pop()

    polygon = Polygon(points)

    # MyCAD convention: polygons are counter-clockwise.
    area = 0.0

    for i in range(len(polygon.points)):
        x1, y1, _ = polygon.points[i]
        x2, y2, _ = polygon.points[
            (i + 1) % len(polygon.points)
        ]

        area += x1 * y2 - x2 * y1

    if area < 0:
        polygon.points.reverse()

    return polygon

def profile_text(text, height=20, font=r"C:\Windows\Fonts\arial.ttf", tracking=0, deflection=DEFAULT_DEFLECTION, x=0, y=0, angle=0):
    """
    Create a MyCAD Profile from a font ShapeString.

    Parameters
    ----------
    text : str
        Text to convert.

    font : str
        Full path to a supported font file.

    height : float
        Text height in mm.

    tracking : float
        Additional spacing between characters in mm.

    deflection : float
        Maximum curve-to-polyline deviation in mm.
    """

    if not isinstance(text, str):
        raise TypeError("text must be a string")

    if not text:
        raise ValueError("text must not be empty")

    if height <= 0:
        raise ValueError("text height must be positive")

    if deflection <= 0:
        raise ValueError("deflection must be positive")

    doc = FreeCAD.newDocument("MyCADText")

    try:
        shapestring = Draft.make_shapestring(
            text,
            font,
            height,
            tracking
        )

        doc.recompute()

        shape = shapestring.Shape

        # Position the text so its bounding-box lower-left
        # corner is at (x, y).
        bounds = shape.BoundBox

        shape = shape.copy()

        shape.translate(
            FreeCAD.Vector(
                x - bounds.XMin,
                y - bounds.YMin,
                0
            )
        )
        # Apply rotation around (x, y)
        if angle != 0:
            #rad = math.radians(angle)
            #rot = FreeCAD.Rotation(FreeCAD.Vector(0,0,1), angle)

            # rotate around the anchor point (x, y)
            shape.rotate(
                FreeCAD.Vector(x, y, 0),
                FreeCAD.Vector(0, 0, 1),
                angle
            )

        regions = []

        for face in shape.Faces:

            region = []

            for wire in face.Wires:
                polygon = _wire_to_polygon(
                    wire,
                    deflection
                )

                region.append(polygon)

            if region:
                regions.append(region)

        if not regions:
            raise ValueError(
                "Font produced no usable geometry"
            )

        profile = Profile.from_regions(regions)

        profile.set_backend_data(
            "freecad",
            shape.copy()
        )

        return profile

    finally:
        FreeCAD.closeDocument(doc.Name)