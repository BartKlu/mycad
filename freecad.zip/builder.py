# mycad/freecad/builder.py

import FreeCAD
import Part
import math
from ..core.pocket import Pocket
from ..core.hole import Hole
from ..core.boss import Boss
from ..core.face import FACE

def make_solid(shape):
    """Create a FreeCAD solid from our Shape."""
    if shape.loft_bottom is not None:
        return make_loft_solid(shape)

    faces = []
    # Bottom faces
    for indexes in shape.polygon.triangulate():
        points = [
            FreeCAD.Vector(*shape.bottom_points[index])
            for index in indexes
        ]
        points.append(points[0])
        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))
    # Top faces
    for indexes in shape.polygon.triangulate():
        points = [
            FreeCAD.Vector(*shape.top_points[index])
            for index in indexes
        ]
        points.append(points[0])
        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))
    # Side faces
    for i, j in shape.polygon.edges():
        points = [
            FreeCAD.Vector(*shape.bottom_points[i]),
            FreeCAD.Vector(*shape.bottom_points[j]),
            FreeCAD.Vector(*shape.top_points[i])
        ]
        points.append(points[0])
        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))
        points = [
            FreeCAD.Vector(*shape.bottom_points[j]),
            FreeCAD.Vector(*shape.top_points[j]),
            FreeCAD.Vector(*shape.top_points[i])
        ]
        points.append(points[0])
        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))
    shell = Part.makeShell(faces)
    solid = Part.makeSolid(shell)
    for feature in shape.features:
        if isinstance(feature, Hole):
            cutter = make_hole_cutter(shape, feature)
            solid = solid.cut(cutter)
        elif isinstance(feature, Pocket):
            cutter = make_profile_pocket(shape, feature)
            solid = solid.cut(cutter)
        elif isinstance(feature, Boss):
            boss_solid = make_profile_boss(shape, feature)
            solid = solid.fuse(boss_solid)
        else:
            raise ValueError(
                f"Unknown feature type: {type(feature).__name__}"
            )
           
    if solid.ShapeType == "Compound" and len(solid.Solids) == 1:
        solid = solid.Solids[0]
    solid = apply_transforms(
        solid,
        shape.transforms
    )
    return solid  
    
def make_hole_cutter(shape, hole):
    """Create a cylindrical cutter for a hole."""
    radius = hole.diameter / 2
    dx, dy, dz = hole.direction
    direction = FreeCAD.Vector(dx, dy, dz)
    if hole.depth is None:
        # Through hole.
        #
        # Make the cutter substantially longer than the object
        # so that it passes completely through it.
        z_values = [p[2] for p in shape.bottom_points + shape.top_points]
        x_values = [p[0] for p in shape.bottom_points + shape.top_points]
        y_values = [p[1] for p in shape.bottom_points + shape.top_points]
        size = max(max(x_values) - min(x_values), max(y_values) - min(y_values), max(z_values) - min(z_values))
        length = size * 3 + 20
        # Start well before the nominal hole position.
        start = FreeCAD.Vector(hole.x - dx * length / 2, hole.y - dy * length / 2, shape.top_z_at(hole.x, hole.y) - dz * length / 2)
        return Part.makeCylinder(radius, length, start, direction)

    else:
        # Blind hole: determine the centre of the entry circle.
        entry = shape.hole_entry_point(hole)
        base = FreeCAD.Vector(*entry)
        direction = FreeCAD.Vector(*hole.direction)
        return Part.makeCylinder(radius, hole.depth, base, direction)

def boolean_cut(shape_a, shape_b):
    """Build two objects and subtract shape_b from shape_a."""

    solid_a = shape_a.build()
    solid_b = shape_b.build()

    result = solid_a.cut(solid_b)

    if result.ShapeType == "Compound" and len(result.Solids) == 1:
        result = result.Solids[0]

    return result

def boolean_fuse(shape_a, shape_b):
    """Build two objects and fuse shape_b with shape_a."""

    solid_a = shape_a.build()
    solid_b = shape_b.build()

    result = solid_a.fuse(solid_b)

    if result.ShapeType == "Compound" and len(result.Solids) == 1:
        result = result.Solids[0]

    return result

def translate_solid(solid, dx=0, dy=0, dz=0):
    """Return a translated copy of a FreeCAD solid."""

    result = solid.copy()
    result.translate(FreeCAD.Vector(dx, dy, dz))
    return result    

def apply_transforms(solid, transforms):
    """Apply recorded rigid transformations in order."""

    result = solid.copy()

    for transform in transforms:

        if transform.kind == "translate":
            dx, dy, dz = transform.values

            result.translate(
                FreeCAD.Vector(dx, dy, dz)
            )

        elif transform.kind == "rotate_z":
            angle, x, y, z = transform.values

            # Positive angle in our API is clockwise when viewed
            # from +Z.
            result.rotate(
                FreeCAD.Vector(x, y, z),
                FreeCAD.Vector(0, 0, 1),
                -angle
            )

        else:
            raise ValueError(
                f"Unknown transformation: {transform.kind}"
            )

    return result
    
def make_profile_prism(profile, bottom_z, top_z):
    """Create a vertical solid/compound from a Profile."""

    backend_shape = profile.get_backend_data("freecad")

    if backend_shape is not None:
        result = backend_shape.copy()

        result.translate(FreeCAD.Vector(0, 0, bottom_z))

        result = result.extrude(
            FreeCAD.Vector(0, 0, top_z - bottom_z)
        )

        return result

    # existing polygon-based implementation follows here

    def make_wire(polygon, z):
        points = [
            FreeCAD.Vector(x, y, z)
            for x, y, _ in polygon.points
        ]

        points.append(points[0])

        return Part.makePolygon(points)


    region_solids = []

    for region in profile.regions:
        outer = region[0]
        holes = region[1:]

        outer_wire = make_wire(outer, bottom_z)

        hole_wires = []

        for hole in holes:
            wire = make_wire(hole, bottom_z)
            wire.reverse()
            hole_wires.append(wire)

        face = Part.Face([outer_wire] + hole_wires)

        solid = face.extrude(
            FreeCAD.Vector(0, 0, top_z - bottom_z)
        )

        region_solids.append(solid)

    if len(region_solids) == 1:
        return region_solids[0]

    compound = Part.makeCompound(region_solids)

    return compound

def _make_surface_profile_prism(shape, feature, direction, length):
    import math
    import FreeCAD, Part

    # --------------------------------------------------------------
    # Determine surface frame (origin, x_axis, y_axis, z_axis)
    # --------------------------------------------------------------

    # Accept 2D or 3D pos; ignore z for placement
    if feature.pos is not None:
        if len(feature.pos) == 2:
            pos1, pos2 = feature.pos
        elif len(feature.pos) == 3:
            pos1, pos2, _ = feature.pos
        else:
            raise ValueError("Feature position must be a 2D or 3D tuple")
    else:
        pos1 = pos2 = 0.0

    # Try inherited frame first
    frame = (
        feature.get_backend_data("top_surface_frame")
        or feature.get_backend_data("bottom_surface_frame")
        or feature.get_backend_data("front_surface_frame")
        or feature.get_backend_data("back_surface_frame")
        or feature.get_backend_data("left_surface_frame")
        or feature.get_backend_data("right_surface_frame")
    )

    if frame is None:
        # Build new frame depending on face
        if feature.face == FACE.TOP:
            origin, x_axis, y_axis, z_axis = shape.top_surface_frame(pos1, pos2)
        elif feature.face == FACE.BOTTOM:
            origin, x_axis, y_axis, z_axis = shape.bottom_surface_frame(pos1, pos2)
        elif feature.face == FACE.FRONT:
            y_wall = min(p[1] for p in shape.bottom_points + shape.top_points)
            origin = (pos1, y_wall, pos2)
            x_axis = (1, 0, 0)
            y_axis = (0, 0, 1)
            z_axis = (0, -1, 0)
        elif feature.face == FACE.BACK:
            y_wall = max(p[1] for p in shape.bottom_points + shape.top_points)
            origin = (pos1, y_wall, pos2)
            x_axis = (1, 0, 0)
            y_axis = (0, 0, 1)
            z_axis = (0, 1, 0)
        elif feature.face == FACE.LEFT:
            x_wall = min(p[0] for p in shape.bottom_points + shape.top_points)
            origin = (x_wall, pos1, pos2)
            x_axis = (0, 1, 0)
            y_axis = (0, 0, 1)
            z_axis = (-1, 0, 0)
        elif feature.face == FACE.RIGHT:
            x_wall = max(p[0] for p in shape.bottom_points + shape.top_points)
            origin = (x_wall, pos1, pos2)
            x_axis = (0, 1, 0)
            y_axis = (0, 0, 1)
            z_axis = (1, 0, 0)
        else:
            raise ValueError(f"Unsupported face: {feature.face}")

    else:
        origin, x_axis, y_axis, z_axis = frame

    # --------------------------------------------------------------
    # Rotation + tilt
    # --------------------------------------------------------------

    radians = math.radians(feature.rotation)
    cos_a = math.cos(radians)
    sin_a = math.sin(radians)

    tilt_x = math.tan(math.radians(feature.tilt_x))
    tilt_y = math.tan(math.radians(feature.tilt_y))

    tx = z_axis[0] + tilt_x * x_axis[0] + tilt_y * y_axis[0]
    ty = z_axis[1] + tilt_x * x_axis[1] + tilt_y * y_axis[1]
    tz = z_axis[2] + tilt_x * x_axis[2] + tilt_y * y_axis[2]

    L = math.sqrt(tx*tx + ty*ty + tz*tz)
    tx /= L; ty /= L; tz /= L

    extrude_vector = FreeCAD.Vector(direction * tx * length,
                                    direction * ty * length,
                                    direction * tz * length)

    # --------------------------------------------------------------
    # Transform profile-local point into world coordinates
    # --------------------------------------------------------------

    def transform_point(point):
        px, py, pz = point
        rx = px * cos_a - py * sin_a
        ry = px * sin_a + py * cos_a
        return FreeCAD.Vector(
            origin[0] + rx * x_axis[0] + ry * y_axis[0],
            origin[1] + rx * x_axis[1] + ry * y_axis[1],
            origin[2] + rx * x_axis[2] + ry * y_axis[2],
        )
    # --------------------------------------------------------------
    # Build solids for each region
    # --------------------------------------------------------------
    region_solids = []

    for region in feature.profile.regions:
        outer = region[0]
        holes = region[1:]

        # Outer wire
        outer_points = [transform_point(p) for p in outer.points]
        outer_points.append(outer_points[0])
        outer_wire = Part.makePolygon(outer_points)

        try:
            outer_face = Part.Face(outer_wire)
            outer_solid = outer_face.extrude(extrude_vector)
        except Exception:
            continue

        # Cut holes
        for hole in holes:
            hole_points = [transform_point(p) for p in hole.points]
            hole_points.append(hole_points[0])
            hole_wire = Part.makePolygon(hole_points)

            try:
                hole_face = Part.Face(hole_wire)
                if hole_face.isNull():
                    continue
                hole_solid = hole_face.extrude(extrude_vector)
                if hole_solid.isNull():
                    continue
                outer_solid = outer_solid.cut(hole_solid)
            except Exception:
                continue

        region_solids.append(outer_solid)

    if len(region_solids) == 1:
        return region_solids[0]

    return Part.makeCompound(region_solids)

def make_profile_boss(shape, boss):
    """Create the solid corresponding to a boss."""
    # Legacy: TOP boss with no explicit position → use top prism
    if boss.pos is None and boss.face == FACE.TOP:
        top_z = shape.max_top_z_in_polygon(boss.profile)
        return make_profile_prism(boss.profile, top_z, top_z + boss.height)
    # For any other face, ensure boss.pos exists
    if boss.pos is None:
        # Derive (x, z) from all regions of the profile
        xs = []
        zs = []
        for region in boss.profile.regions:
            for poly in region:
                for (x, y, z) in poly.points:
                    xs.append(x)
                    zs.append(z)
        if not xs or not zs:
            raise ValueError("Cannot derive boss.pos from empty profile")
        cx = (min(xs) + max(xs)) / 2.0
        cz = (min(zs) + max(zs)) / 2.0
        boss.pos = (cx, cz)
    # Use the unified surface-frame prism builder
    return _make_surface_profile_prism(shape, boss, direction=1, length=boss.height)

def make_profile_pocket(shape, pocket):
    """Create the solid used to cut a pocket."""
    # If no explicit pos, derive it from the profile (same idea as boss)
    if pocket.pos is None:
        xs = []
        zs = []
        for region in pocket.profile.regions:
            for poly in region:
                for (x, y, z) in poly.points:
                    xs.append(x)
                    zs.append(z)
        if not xs or not zs:
            raise ValueError("Cannot derive pocket.pos from empty profile")
        cx = (min(xs) + max(xs)) / 2.0
        cz = (min(zs) + max(zs)) / 2.0
        pocket.pos = (cx, cz)
    # Extend the cutter slightly past the requested depth so the Boolean cut is not exactly tangent at the bottom.
    return _make_surface_profile_prism(shape, pocket, direction=-1, length=pocket.depth + 0.01)

def make_loft_solid(shape):
    bottom_pts = shape.loft_bottom   # list of (x, y)
    top_pts    = shape.loft_top      # list of (x, y)
    bottom_z = 0
    top_z    = shape.top_z

    n = len(bottom_pts)
    faces = []

    # ------------------------------------------------------------
    # Bottom face (Z = 0)
    # ------------------------------------------------------------
    bottom_vectors = [
        FreeCAD.Vector(x, y, bottom_z)
        for (x, y) in bottom_pts
    ]
    bottom_vectors.append(bottom_vectors[0])
    bottom_wire = Part.makePolygon(bottom_vectors)
    faces.append(Part.Face(bottom_wire))

    # ------------------------------------------------------------
    # Top face (Z = shape.top_z)
    # ------------------------------------------------------------
    top_vectors = [
        FreeCAD.Vector(x, y, top_z)
        for (x, y) in top_pts
    ]
    top_vectors.append(top_vectors[0])
    top_wire = Part.makePolygon(top_vectors)
    faces.append(Part.Face(top_wire))

    # ------------------------------------------------------------
    # Side faces (quad between bottom[i], bottom[j], top[j], top[i])
    # ------------------------------------------------------------
    for i in range(n):
        j = (i + 1) % n

        b0 = FreeCAD.Vector(bottom_pts[i][0], bottom_pts[i][1], bottom_z)
        b1 = FreeCAD.Vector(bottom_pts[j][0], bottom_pts[j][1], bottom_z)
        t1 = FreeCAD.Vector(top_pts[j][0],    top_pts[j][1],    top_z)
        t0 = FreeCAD.Vector(top_pts[i][0],    top_pts[i][1],    top_z)
        
        quad = Part.makePolygon([b0, b1, t1, t0, b0])
        faces.append(Part.Face(quad))

    # ------------------------------------------------------------
    # Build shell + solid
    # ------------------------------------------------------------
    shell = Part.makeShell(faces)
    solid = Part.makeSolid(shell)

    # ------------------------------------------------------------
    # Apply features (holes, pockets, bosses)
    # ------------------------------------------------------------
    for feature in shape.features:
        if isinstance(feature, Hole):
            cutter = make_hole_cutter(shape, feature)
            solid = solid.cut(cutter)
        elif isinstance(feature, Pocket):
            cutter = make_profile_pocket(shape, feature)
            solid = solid.cut(cutter)
        elif isinstance(feature, Boss):
            boss_solid = make_profile_boss(shape, feature)
            solid = solid.fuse(boss_solid)

    # ------------------------------------------------------------
    # Apply transforms
    # ------------------------------------------------------------
    solid = apply_transforms(solid, shape.transforms)

    return solid
    
class BuiltShape:
    def __init__(self, core_shape, fc_shape):
        self.core = core_shape
        self.fc = fc_shape

    def text_on_face(self, text, face, u=0.5, v=0.5, height=5, inset=0):
        from mycad.freecad.face_ops import text_on_face
        return text_on_face(self.core, self.fc, text, face, u, v, height, inset)

    