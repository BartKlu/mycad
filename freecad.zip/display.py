# mycad/freecad/display.py

import FreeCAD
import FreeCADGui
import Part


def show_polygon(polygon):
    """Display the triangulated polygon in FreeCAD."""

    doc = FreeCAD.newDocument("MyCAD")

    for number, indexes in enumerate(polygon.triangulate()):

        points = [
            FreeCAD.Vector(*polygon.points[index])
            for index in indexes
        ]

        points.append(points[0])

        wire = Part.makePolygon(points)
        face = Part.Face(wire)

        obj = doc.addObject("Part::Feature", f"Triangle_{number}")
        obj.Shape = face

    doc.recompute()

    FreeCADGui.activeDocument().activeView().viewTop()
    FreeCADGui.activeDocument().activeView().fitAll()

    return doc
    
def show_shape(shape):
    """Display a Shape as a collection of triangular faces."""

    doc = FreeCAD.newDocument("MyCAD")

    faces = []

    # Bottom faces
    for indexes in shape.polygon.triangulate():
        points = [
            FreeCAD.Vector(*shape.bottom_points[index])
            for index in indexes
        ]

        points.append(points[0])

        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))

    # Top faces
    for indexes in shape.polygon.triangulate():
        points = [
            FreeCAD.Vector(*shape.top_points[index])
            for index in indexes
        ]

        points.append(points[0])

        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))

    # Side faces
    for i, j in shape.polygon.edges():

        # First triangle
        points = [
            FreeCAD.Vector(*shape.bottom_points[i]),
            FreeCAD.Vector(*shape.bottom_points[j]),
            FreeCAD.Vector(*shape.top_points[i]),
        ]

        points.append(points[0])

        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))

        # Second triangle
        points = [
            FreeCAD.Vector(*shape.bottom_points[j]),
            FreeCAD.Vector(*shape.top_points[j]),
            FreeCAD.Vector(*shape.top_points[i]),
        ]

        points.append(points[0])

        wire = Part.makePolygon(points)
        faces.append(Part.Face(wire))

    compound = Part.makeCompound(faces)

    obj = doc.addObject("Part::Feature", "Shape")
    obj.Shape = compound

    doc.recompute()

    FreeCADGui.activeDocument().activeView().viewAxonometric()
    FreeCADGui.activeDocument().activeView().fitAll()

    return obj    
